
/* ////////////////////////////////////////////////////////////////
Developd by Dr. Oguz Emrah Turgut,
Mechanical Engineer,
Izmir Bakircay University
E-mail:oeturgut@hotmail.com


% Main paper (Please refer to the main paper):
% Slime Mould Algorithm: A New Method for Stochastic Optimization
% Shimin Li, Huiling Chen, Mingjing Wang, Ali Asghar Heidari, Seyedali Mirjalili
% Future Generation Computer Systems,2020
% DOI: https://doi.org/10.1016/j.future.2020.03.055
% https://www.sciencedirect.com/science/article/pii/S0167739X19320941
% ------------------------------------------------------------------------------------------------------------
% Website of SMA: http://www.alimirjalili.com/SMA.html
% You can find and run the SMA code online at http://www.alimirjalili.com/SMA.html

% You can find the SMA paper at https://doi.org/10.1016/j.future.2020.03.055
% Please follow the paper for related updates in researchgate: https://www.researchgate.net/publication/340431861_Slime_mould_algorithm_A_new_method_for_stochastic_optimization


/////////////////////////////////////////////////////////////
 */
import java.util.*;
import java.io.*;

abstract class f_xj
{
abstract double func(double x[]);
}

public class Slime_Mould_Algorithm
{
double[][] X;
double[][] weight;
double[] Lower;
double[] Upper;
double Maxiter;
double iter;
double[] AllFitness;
double[] SmellOrder;
int[] SmellIndex;
double[] bestPositions;
double worstFitness;
double bestFitness;
double Destination_fitness;
double a;
double b;
double z;
double p;
double S;
double r;
double eps;
f_xj ff;
int N;
int D;
int A;
int B;

	public Slime_Mould_Algorithm(f_xj iff,int iN,double[] iLower,double[] iUpper, int iMaxiter)
    {
    Lower=iLower;
	Upper=iUpper;	
	ff=iff;
	N=iN;
	D=Lower.length;
	Maxiter=iMaxiter;	
	ff=iff;	
    weight=new double[N][D];
    X=new double[N][D];
    AllFitness=new double[N];
    SmellOrder=new double[N];
    SmellIndex=new int[N];
    bestPositions=new double[D];
	z=0.03;
    eps=0.000000000000000000001;
    Destination_fitness=1E+200;
    
    }

    void init()
    {
	   for(int i=0;i<N;i++)
	   {
	      for(int j=0;j<D;j++)
	      {
		  X[i][j]=Lower[j]+(Upper[j]-Lower[j])*Math.random();
		  }	   
	 	  AllFitness[i]=ff.func(X[i]);
	   }     
	}

	double[][] sort_and_index(double[] A)
	{
		ArrayList<Double> B=new ArrayList<Double>(); 	
		for(int i=0;i<A.length;i++)
		{B.add(A[i]);}	
		ArrayList<Double> nstore=new ArrayList<Double>(B);
		Collections.sort(B);
		double[] ret=new double[B.size()];
		Iterator<Double> iterator=B.iterator();
		int ii=0;
		while(iterator.hasNext())
		{ret[ii]=iterator.next().doubleValue();ii++;}
		int[] indexes=new int[B.size()];
		for(int n=0;n<B.size();n++)
		{indexes[n]=nstore.indexOf(B.get(n));}
		double[][] outt=new double[2][B.size()];
		for(int i=0;i<B.size();i++)
		{outt[0][i]=ret[i];outt[1][i]=indexes[i];}
		return outt;
	}
    
	int randint()
	{return (int)(Math.floor(Math.random()*(double)N));}
	
	
	
	
    double[] unifrnd(double a1, double a2)
    {
	   double[] vout=new double[D];
	    
	  
	      for(int j=0;j<D;j++)
	      {
		  vout[j]=a1+(a2-a1)*Math.random();    
		  }	   
		   
	   
	   return vout;     
	}

	double atanh(double x)
	{return 0.5*Math.log( (x + 1.0) / (x - 1.0));}
	
	double[][] solution()
	{
		init();
		iter=1;
		
		while(iter<Maxiter)
		{
			
	   		for(int i=0;i<N;i++)
	   		{
	      		for(int j=0;j<D;j++)
	      		{
		  		   if(((X[i][j])<Lower[j])||((X[i][j])>Upper[j]))
		      	   {X[i][j]=Lower[j]+(Upper[j]-Lower[j])*Math.random();};
		  		}	   
	 	  		AllFitness[i]=ff.func(X[i]);
	   		}     
	   		double[][] Smell=sort_and_index(AllFitness);
	   		
	   		for(int i=0;i<N;i++)
	   		{SmellOrder[i]=Smell[0][i];SmellIndex[i]=(int)Smell[1][i];} 
	   		worstFitness=SmellOrder[N-1];
	   		bestFitness=SmellOrder[0];
	   		S=bestFitness-worstFitness+eps;			
			
	        for(int i=0;i<N;i++)
	        {
		       for(int j=0;j<D;j++)
		       {
			       if(i<(N/2))
			       {
				     weight[SmellIndex[i]][j]=1.0+Math.random()*Math.log10(((bestFitness-SmellOrder[i])/S)+1.0);    
				   }
			       else
			       {
				     weight[SmellIndex[i]][j]=1.0-Math.random()*Math.log10(((bestFitness-SmellOrder[i])/S)+1.0);  
				   }   
			       
			   }    
		    }		
			
		    if(bestFitness < Destination_fitness)
		    {
			    for(int j=0;j<D;j++)
			    {bestPositions[j]=X[SmellIndex[0]][j];}    
			    Destination_fitness=bestFitness;
			}
			
			
			a=atanh(1.0-(((double)iter-eps)/(double)Maxiter));
			b=1.0-(double)iter/(double)Maxiter;
			
			for(int i=0;i<N;i++)
			{
			     if(Math.random()<z)
			     {
				     for(int j=0;j<D;j++)
				     {X[i][j]=Lower[j]+(Upper[j]-Lower[j])*Math.random();}    
				 }	
				
				 p=Math.tanh(Math.abs(AllFitness[i]-Destination_fitness));
				 double[] vb=unifrnd(-a,a);
				 double[] vc=unifrnd(-b,b);
				 
				 for(int j=0;j<D;j++)
				 {
					r=Math.random(); 
					A=randint(); 
					B=randint();  
					if(r<p)
					{
						X[i][j]=bestPositions[j]+vb[j]*(weight[i][j]*X[A][j]-X[B][j]);	
				    }
					else
					{
						X[i][j]=vc[j]*X[i][j];
					}
				 }
				
			}
			
		iter++;	
		}
 
		
	   double[][] out=new double[2][D];
	   for(int j=0;j<D;j++)
	   {out[0][j]=bestPositions[j];}  
	    out[1][0]=Destination_fitness;
	   return out;
	}
 
 void toStringnew()
{
  double[][] out=solution();
  System.out.println("Optimized value = "+out[1][0]);
  for(int i=0;i<D;i++)
  {System.out.println("x["+i+"] = "+out[0][i]);}	
}


}