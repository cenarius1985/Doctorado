 
/* ////////////////////////////////////////////////////////////////
Developd by Dr. Oguz Emrah Turgut,
Mechanical Engineer,
Izmir Bakircay University
E-mail:oeturgut@hotmail.com


% Main paper (Please refer to the main paper):
% Slime Mould Algorithm: A New Method for Stochastic Optimization
% Shimin Li, Huiling Chen, Mingjing Wang, Ali Asghar Heidari, Seyedali Mirjalili
% Future Generation Computer Systems,2020
% DOI: https://doi.org/10.1016/j.future.2020.03.055
% https://www.sciencedirect.com/science/article/pii/S0167739X19320941
% ------------------------------------------------------------------------------------------------------------
% Website of SMA: http://www.alimirjalili.com/SMA.html
% You can find and run the SMA code online at http://www.alimirjalili.com/SMA.html

% You can find the SMA paper at https://doi.org/10.1016/j.future.2020.03.055
% Please follow the paper for related updates in researchgate: https://www.researchgate.net/publication/340431861_Slime_mould_algorithm_A_new_method_for_stochastic_optimization


/////////////////////////////////////////////////////////////
 */

class f1 extends f_xj//Gold stein f(x)=3.0 @x=(0,-1) -2<x[i]<2 i=1,2
{
double func(double x[])
{
double first=0.0;double second=0.0;
first=(1.0+(x[0]+x[1]+1.0)*(x[0]+x[1]+1.0)*(19.0-14.0*x[0]+3.0*x[0]*x[0]-14.0*x[1]+6.0*x[0]*x[1]+3.0*x[1]*x[1]));	
second=30.0+(2.0*x[0]-3.0*x[1])*(2.0*x[0]-3.0*x[1])*(18.0-32.0*x[0]+12.0*x[0]*x[0]+48.0*x[1]-36.0*x[0]*x[1]+27*x[1]*x[1]);	
return first*second;	
}	
}

class f2 extends f_xj// Beale f(x)=0    @x=(3,0.5)   -4.5<x[i]<4.5, i = 1, 2.
{
double func(double x[])
{
double first=0.0;	
first=((1.5-x[0]+x[0]*x[1])*(1.5-x[0]+x[0]*x[1]))+((2.25-x[0]+x[0]*x[1]*x[1])*(2.25-x[0]+x[0]*x[1]*x[1]))+((2.625-x[0]+x[0]*x[1]*x[1]*x[1])*(2.625-x[0]+x[0]*x[1]*x[1]*x[1]));
return first;	
}	
}

class f3 extends f_xj// Bohachecsky 1 f(x)=0  @x=(0.0,0.0)   -5.0<x[i]<5.0, i = 1, 2.
{
double func(double x[])
{
double first=0.0;	
first=x[0]*x[0]+2.0*x[1]*x[1]-0.3*(Math.cos(Math.PI*3.0*x[0]))-0.4*Math.cos(4.0*Math.PI*x[1])+0.7;
return first;	
}	
}

class f4 extends f_xj// Bohachecsky 2 f(x)=0  @x=(0.0,0.0)   -5.0<x[i]<5.0, i = 1, 2.
{
double func(double x[])
{
double first=0.0;	
first=x[0]*x[0]+2.0*x[1]*x[1]-(0.3*(Math.cos(Math.PI*3.0*x[0]))*Math.cos(4.0*Math.PI*x[1]))+0.3;
return first;	
}	
}

class f5 extends f_xj// Bohachecsky 3 f(x)=0  @x=(0.0,0.0)   -5.0<x[i]<5.0, i = 1, 2.
{
double func(double x[])
{
double first=0.0;	
first=x[0]*x[0]+2.0*x[1]*x[1]-(0.3*(Math.cos(Math.PI*3.0*x[0]+Math.PI*4.0*x[1])))+0.3;
return first;	
}	
}

class f6 extends f_xj// Booth  f(x)=0  @x=(1.0,3.0)   -10.0<x[i]<10.0, i = 1, 2.
{
double func(double x[])
{
double first=0.0;	
first=(x[0]+2.0*x[1]-7.0)*(x[0]+2.0*x[1]-7.0)+(2.0*x[0]+x[1]-5.0)*(2.0*x[0]+x[1]-5.0);
return first;	
}	
}

class f7 extends f_xj// Branin  f(x)=0.397887  @x=(-pi,12.275),(pi,2.275),(9.42478,2.475)   -5.0<=x[0]<=10.0, 0.0<=x[1]<=15.0
{
double func(double x[])
{
double first=0.0;	
first=((x[1]-(5.1*x[0]*x[0]/(4.0*Math.PI*Math.PI))+(5.0*x[0]/Math.PI)-6.0)*(x[1]-(5.1*x[0]*x[0]/(4.0*Math.PI*Math.PI))+(5.0*x[0]/Math.PI)-6.0))+(10.0*(1.0-(1.0/(8.0*3.1415)))*Math.cos(x[0]))+10.0;
return first;	
}	
}

class f8 extends f_xj// Colville  f(x)=0.0  @x=(1,1,1,1)   -10.0<=x[i]<=10.0 i=0,1,2,3
{
double func(double x[])
{
double first=0.0;	
first=(100.0*(x[0]-x[1]*x[1])*(x[0]-x[1]*x[1]))+((1.0-x[0])*(1.0-x[0]))+(90.0*(x[3]-x[2]*x[2])*(x[3]-x[2]*x[2]))+((1.0-x[2])*(1.0-x[2]))+(10.1*((x[1]-1.0)*(x[1]-1.0)+(x[3]-1.0)*(x[3]-1.0)))+(19.8*(x[1]-1.0)*(x[3]-1.0));
return first;	
}	
}

class f9 extends f_xj// Easom  f(x)=-1.0  @x=(pi,pi)   -100.0<=x[i]<=100.0 i=0,1
{
double func(double x[])
{
double first=0.0;	
first=-Math.cos(x[0])*Math.cos(x[1])*Math.exp(-(x[0]-Math.PI)*(x[0]-Math.PI)-(x[1]-Math.PI)*(x[1]-Math.PI));
return first;	
}	
}

class f10 extends f_xj// Himmelblau f(x)=0.0  @x=(3.0,2.0),(-2.8051,3.1313),(-3.7793,-3.2831),(3.5844,-1.8481)   -6.0<=x[i]<=6.0 i=0,1
{
double func(double x[])
{
double first=0.0;	
first=(((x[0]*x[0]+x[1]-11.0)*(x[0]*x[0]+x[1]-11.0))+(x[0]+x[1]*x[1]-7.0)*(x[0]+x[1]*x[1]-7.0));
return first;	
}	
}

class f11 extends f_xj// Griewank f(x)=0.0  @x=(0,0)<---global minima     several local minimas      -600<x[i]<600 i=1,2,.. x.length 
{
double func(double x[])
{
   double s=0.0;
   double fact=1.0;
   int m=x.length;
   for(int i=0;i<m;i++)
   {s+=x[i]*x[i];}	
   for(int i=0;i<m;i++)
   {fact*=Math.cos(x[i]/Math.sqrt(i+1));}
   return (s/4000.0)+1.0+(-fact);	
}	
}

class f12 extends f_xj// Hartman3 f(x)=-3.86  @x=(0.114,0.556,0.852)   0.0<x[i]<1.0 for n=3 variable 
{
double func(double x[])
{
double[][] A={{3.0,10.0,30.0},{0.1,10.0,35.0},{3.0,10.0,30.0},{0.1,10.0,35.0}};
double c[]={1.0,1.2,3.0,3.2};
double p[][]={{0.3689,0.1170,0.2673},{0.4699,0.4387,0.7470},{0.1091,0.8732,0.5547},{0.03815,0.5743,0.8828}}   ;
double sin;
double sout=0.0;
    for(int i=0;i<=3;i++)	
    {  sin=0.0;
	    for(int j=0;j<=3;)
	   {sin+=A[i][j]*(x[j]-p[i][j])*(x[j]-p[i][j]);} 
	   sout+=c[i]*Math.exp(-sin);}	
	
return -sout;	
}	
}

class f13 extends f_xj// Matyas function f(x)=0.0 @x(0,0)  -10.0<=x[i]<=10.0
{
double func(double x[])
{
return 0.26*(x[0]*x[0]+x[1]*x[1])-0.48*x[0]*x[1];
}	
}

class f14 extends f_xj //Michalewicz n=x.length=2 f(x)=-1.8013    0<=x[i]<=pi
{                                        //    =5 f(x)=-4.687658        
   double func(double x[])               //   =10 f(x)=-9.66015  
   {
	int n=x.length;   
	double m=10.0;
	double s=0.0;
	for(int i=0;i<n;i++)
	{s+=Math.sin(x[i])*Math.pow(Math.sin(((double)i+1.0)*x[i]*x[i]/3.1415),2.0*m);}   
	return -s;   
   }	
}

class f15 extends f_xj //Perm function!!!!!! error  
{                                               
   double func(double x[])                
   {
	int n=x.length;   
	double b=0.5;

	double sin;
	double sout=0.0;
	for(int k=0;k<n;k++)
	{sin=0.0;
	 for(int i=0;i<n;i++)
	 {sin+=(Math.pow((double)i,(double)k)+b)*(Math.pow((x[i]/(double)i),(double)k)-1.0);}	
	 sout+=sin*sin;	
	}
	return sout;   
   }	
}

class f16 extends f_xj //Powell function !!Error     Must--->mod(x.length,4)==0 
{                                               
   double func(double x[])                
   {
	int n=x.length;
	int m=n/4;double s=0.0;
	for(int j=1;j<=m;j++)
	{s+=((x[4*j-4]+10.0*x[4*j-3])*(x[4*j-4]+10.0*x[4*j-3]))+(Math.sqrt(5.0)*(x[4*j-2]-x[4*j-1])*(x[4*j-2]-x[4*j-1]))+(Math.pow((x[4*j-3]-2.0*x[4*j-2]),4.0))+(Math.sqrt(10.0)*Math.pow(x[4*j-4]-x[4*j-1],4.0));}
	return s;
	   
   }
}

class f17 extends f_xj //Shekel function     f(x)=-10.1532 m=5; @x=(4,4,4,4) 0<=x[i]<=10.0   
{                                          //f(x)=-10.4029 m=7;     
   double func(double x[])                 //f(x)=-10.5364 m=10;
   {
	int n=x.length;
	double A[][]={{4.0,4.0,4.0,4.0},{1.0,1.0,1.0,1.0},{8.0,8.0,8.0,8.0},{6.0,6.0,6.0,6.0},{3.0,7.0,3.0,7.0},{2.0,9.0,2.0,9.0},{5.0,5.0,3.0,3.0},{8.0,1.0,8.0,1.0},{6.0,2.0,6.0,2.0},{7.0,3.6,7.0,3.6}};
	double c[]={0.1,0.2,0.2,0.4,0.4,0.6,0.3,0.7,0.5,0.5};
	double sin=0.0;
	double sout=0.0;
	for(int i=0;i<10;i++)
	{ sin=c[i];
	  for(int j=0;j<n;j++)	
	  {sin+=(x[j]-A[i][j])*(x[j]-A[i][j]);}
	  sout+=(1.0/sin);	
	}
	return -sout;
	}
}

class f18 extends f_xj //Trid function     f(x)=-50.0 x.length=6;  -x.length^2<=x[i]<=x.length^2   
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;double s2=0.0;
	for(int i=0;i<n;i++)
	{s1+=Math.pow(x[i]-1.0,2.0);}
	for(int i=1;i<n;i++)
	{s2+=x[i]*x[i-1];}
	return s1-s2;
	}
}

class f19 extends f_xj //Zakharov function     f(x)=0.0 @x=(0,0,..)   -5<=x[i]<=10   
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;double s2=0.0;double s3=0.0;
	for(int i=0;i<n;i++)
	{s1+=x[i]*x[i];}
	for(int i=0;i<n;i++)
	{s2+=0.5*(double)i*x[i];}
	return s1+Math.pow(s2,2.0)+Math.pow(s2,4.0);
	
	}
}

class f20 extends f_xj //Levy function         f(x)=0   @x=(1,1,1...) -10<x[i]<10 
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double z[]=new double[n];
	for(int i=0;i<n;i++)
	{z[i]=1.0+((x[i]-1.0)/4.0);}
	double s=Math.pow(Math.sin(3.1415*z[0]),2.0);
	for(int i=0;i<n-1;i++)
	{s+=Math.pow((z[i]-1.0),2.0)*(1.0+10.0*Math.pow(Math.sin(3.1415*z[i]+1.0),2.0));}
	return s+Math.pow(z[n-1]-1.0,2.0)*(Math.pow(Math.sin(2.0*3.1415*z[n-1]),2.0)+1.0);
   }
}


class f21 extends f_xj //Dixon price function         f(x)=0    -10<x[i]<10 
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;
	for(int i=1;i<n;i++)
	{s1+=((double)i+1.0)*(2.0*x[i]*x[i]-x[i-1])*(2.0*x[i]*x[i]-x[i-1]);}
	return s1+(x[0]-1.0)*(x[0]-1.0);
	}
}

class f22 extends f_xj //Salomon's function         f(x)=0      @x=(0,0,0...) -10<x[i]<10 
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;
    for(int i=0;i<n;i++)
    {s1+=x[i]*x[i];}
    s1=Math.sqrt(s1);
	return -Math.cos(2.0*3.1415*s1)+0.1*s1+1.0;	
   }
}

class f23 extends f_xj //Whitley's function         f(x)=0      @x=(0,0,0...) -10<x[i]<10 
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;
    for(int i=0;i<n;i++)
    {
	  for(int j=0;j<n;j++)
	  {s1+=(Math.pow((100.0*(x[i]*x[i]-x[j])*(x[i]*x[i]-x[j])+(1.0-x[j])*(1.0-x[j])),2.0)/4000.0)-Math.cos((100.0*(x[i]*x[i]-x[j])*(x[i]*x[i]-x[j])+(1.0-x[j])*(1.0-x[j])))+1.0;}    
	}
	return s1;
  }
}

class f24 extends f_xj //quartic function         f(x)=0      @x=(0,0,0...) -10<x[i]<10 
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;
    for(int i=0;i<n;i++)
    {s1+=((double)i+1.0)*Math.pow(x[i],4.0);}
    s1+=Math.random();
	return s1;
  }
}

class f25 extends f_xj //quartic function         f(x)=0      @x=(0,0,0...) -10<x[i]<10 
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;
    for(int i=0;i<n;i++)
    {s1+=((double)i+1.0)*Math.pow(x[i],4.0);}
    s1+=Math.random();
	return s1;
  }
}

class f26 extends f_xj //Camel Back -6 Hump function         f(x)=-1.0316285       -5<x[i]<5 
{                                              
   double func(double x[])                 
   {
	int n=x.length;
    double s1=4.0*x[0]*x[0]-2.1*x[0]*x[0]*x[0]*x[0]+(x[0]*x[0]*x[0]*x[0]*x[0]*x[0]/3.0)+(x[0]*x[1])-4.0*x[1]*x[1]+4.0*x[1]*x[1]*x[1]*x[1];
    return s1;
   }
}

class f27 extends f_xj //Schwefel 2.22         f(x)=0    @x=(0,0,...)  -100<x[i]<100  
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;
	double f1=1.0;
    for(int i=0;i<n;i++)
    {s1+=Math.abs(x[i]);f1*=Math.abs(x[i]);}
    return s1+f1;
   }
}

class f28 extends f_xj //Kowalik         f(x)=3.0748e-4    @x=(0,0,...)  -5<x[i]<5  
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double a[]={0.1957,0.1947,0.1735,0.16,0.0844,0.0627,0.0456,0.0342,0.0323,0.0235,0.0246};
    double b[]={0.25, 0.5, 1.0, 2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0};
    double s1=0.0;
    for(int i=0;i<11;i++)
    {s1+=Math.pow((a[i]-((x[0]*(1.0+x[1]*b[i]))/(1.0+x[2]*b[i]+x[3]*b[i]*b[i]))),2.0);              }
    return s1;
   }
}

class f29 extends f_xj //Schaffer function         f(x)=0    @x=(0,0,...)  -100<x[i]<100  
{                                              
   double func(double x[])                 
   {
	int n=x.length;
	double s1=0.0;
	for(int i=0;i<n;i++)
	{s1+=x[i]*x[i];}
	double s2=Math.sqrt(s1);
	return 0.5+((Math.pow(Math.sin(s1),2.0)-0.5)/(1.0+0.001*s1));
	}
}


class f30 extends f_xj  // Rosenbrock's valley     f(x)=0.0     -2.048<x[i]<2.048
{
double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;
double ff=0.0;
for(int i=0;i<n-1;i++)
{ff+=(100.0*(x[i+1]-x[i]*x[i])*(x[i+1]-x[i]*x[i])+(1.0-x[i])*(1.0-x[i]));}
return ff; 
}
}

class f31 extends f_xj // De Jong�s first function     f(x)=0  @x=(0,0,...)     -5.12<x[i]<5.12
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double ff=0;
int n=x.length;
for(int i=0;i<n;i++)
{ff+=x[i]*x[i];}
return ff;
}
} 

class f311 extends f_xj // De Jong�s first function     f(x)=0  @x=(0,0,...)     -5.12<x[i]<5.12
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double ff=0;
int n=x.length;
for(int i=0;i<n;i++)
{ff+=x[i];}
return ff;
}
}


class f32 extends f_xj //Axis parallel hyper-ellipsoid 2.2    f(x)=0  @x=(0,0,...)     -5.12<x[i]<5.12
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double ff=0;
int n=x.length;

for(int i=0;i<n;i++)
{ff+=i*x[i]*x[i];}
return ff;
}
}

class f33 extends f_xj //Rotated hyper-ellipsoid function  -65.536<x[i]<65.536  f(x)=0   @x=(0,0,...)
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double ff=0;
int n=x.length;

for(int i=0;i<n;i++)
{
  for(int j=0;j<i;j++)
  {ff+=x[j]*x[j];}	
}
return ff;
}
}

class f34 extends f_xj //Rastrigin�s function 2.5        f(x)=0  @x=(0,0,...)     -5.12<x[i]<5.12
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double ff=0;
int n=x.length;
for(int i=0;i<n;i++)
{
ff+=x[i]*x[i]-10*Math.cos(2.0*Math.PI*x[i]);
}
return ff+10*n;
}
}

class f35 extends f_xj //sum of a different power function 2.8       f(x)=0   @x=(0,0,...)      -1<x[i]<1
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double ff=0;
int n=x.length;
double top=0;
for(int i=0;i<n;i++)
{top+=Math.pow(Math.abs(x[i]),(i+2));}
return top;
}
} 

class f36 extends f_xj //Ackley�s function 2.9        f(x)=0;      @x=(0,0,0...)     -32.768<x[i]<32.768
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double a=20.0;
double b=0.2;
double c=2.*Math.PI;

int n=x.length;

double r=Math.PI/180;
double top1=0.0;
for(int i=0;i<n;i++)
{top1+=x[i]*x[i];}
top1=Math.sqrt(top1/n);
double top2=0.0;
for(int i=0;i<n;i++)
{top2+=Math.cos(r*c*x[i]);}
top2=top2/n;
double top=-a*Math.exp(-b*top1)-Math.exp(top2)+a+Math.exp(1);
return top;
}
}

class f37 extends f_xj //�Drop wave� function ++        i=1,2...    f(x)=-1.0  @x=(0,0)   -5.12<x[i]<5.12
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double r=Math.PI/180;
double top1=-(1+Math.cos((12*Math.sqrt(x[0]*x[0]+x[1]*x[1]))))/(0.5*(x[0]*x[0]+x[1]*x[1])+2.0);
return top1;
}
}

class f38 extends f_xj //Shubert�s function   -10<x[i]<10   18 global minima
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	

double r=Math.PI/180;
double top1=0;
double top2=0;
for(int i=1;i<=5;i++)     
{top1+=i*Math.cos((i+1)*x[0]+1);}
for(int i=1;i<=5;i++)     
{top2+=i*Math.cos((i+1)*x[1]+1);}
return -top1*top2;
}
}

class f39 extends f_xj //Fletcher and Powell function---> min(alfa)<x[i]<max(alfa)  f(x)=0 @x=(alfa[1],alfa[2],,,alfa[i]) 
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double a[][]={{-79.0, 56.0, -62.0, -9.0, 92.0, 48.0, -22.0, -34.0, -39.0, -40.0, -95.0, -69.0, -20.0, -66.0, -98.0, -66.0,-67.0, 37.0,-83.0, -45.0},{91.0, -9.0, -18.0, -59.0, 99.0, -45.0, 88.0, -14.0, -29.0, 26.0, 71.0, -65.0, 19.0, 45.0, 88.0, 18.0, -11.0, -81.0, -10.0, 42.0},{-38.0, 8.0, -12.0, -73.0, 40.0, 26.0, -64.0, 29.0, -82.0, -32.0, -89.0, -3.0, 88.0, 98.0, 53.0, 58.0, 45.0, -39.0, 34.0, -23.0},{-78.0,-18.0 -49.0, 65.0, 66.0, -40.0, 88.0, -95.0, -57.0, 10.0, -98.0, -11.0, -16.0, -55.0, 33.0, 84.0, 21.0, -43.0, 45.0, 100.0,},{-1.0, -43.0, 93.0, -18.0, -76.0, -68.0, -42.0, 22.0, 46.0, -14.0, 69.0, 27.0, -12.0, -26.0, 57.0, -13.0, 0.0, 1.0, 56.0, 17.0},{34.0, -96.0, 26.0, -56.0, -36.0, -85.0, -62.0, 13.0, 93.0, 78.0, -43.0, 96.0, 77.0, 65.0, -34.0, -52.0, 82.0, 18.0, -59.0, -55.0},{52.0, -46.0, -69.0, 99.0, -47.0, -72.0, -11.0, 55.0, -55.0, 91.0, -30.0, 7.0, -35.0, 23.0, -20.0, 55.0, 61.0, -39.0, -58.0, 13.0},{81.0, 47.0, 35.0, 55.0, 67.0, -13.0, 33.0, 14.0, 83.0, -42.0, 8.0, -45.0, -44.0, 12.0, 100.0, -9.0,-33.0, -11.0, 21.0, 14.0},{5.0, -43.0, -45.0, 46.0, 56.0, -94.0, -62.0, 52.0, 66.0, 55.0, -86.0, -29.0, -52.0, -71.0, -91.0, -46.0, 27.0, -27.0, 6.0, 67.0},{-50.0, 66.0, -47.0, -75.0, 89.0, -16.0, 82.0, 6.0, -85.0, -62.0, -30.0, 31.0, -7.0, -75.0, -26.0, -24.0, 46.0, -95.0, -71.0, -57.0},{24.0, 98.0, -50.0, 68.0, -97.0, -64.0, -24.0, 81.0, -59.0, -7.0, 85.0, -92.0, 2.0, 61.0, 52.0, -59.0, -91.0, 74.0, -99.0, -95.0},{-30.0, -63.0, -32.0, -90.0, -35.0, 44.0, -64.0, 57.0, 27.0, 87.0, -70.0, -39.0, -18.0, -89.0, 99.0, 40.0, 14.0, -58.0 ,-5.0, -42.0},{56.0, 3.0, 88.0, 38.0, -14.0, -15.0, 84.0, -9.0, 65.0, -20.0, -75.0, -37.0, 74.0, 66.0, -44.0, 72.0, 74.0, 90.0, -83.0, -40.0},{84.0, 1.0, 73.0, 43.0, 84.0, -99.0, -35.0, 24.0, -78.0, -58.0, 47.0, -83.0, 94.0, -86.0, -65.0, 63.0, -22.0, 65.0, 50.0, -40.0},{-21.0, -8.0, -48.0, 68.0, -91.0, 17.0, -52.0, -99.0, -23.0, 43.0, -8.0, -5.0, -98.0, -17.0, -62.0, -79.0, 60.0, -18.0, 54.0, 74.0},{35.0, 93.0, -98.0, -88.0, -8.0, 64.0, 15.0, 69.0, -65.0, -86.0, 58.0, -44.0, -9.0, -94.0, 68.0, -27.0, -79.0, -67.0, -35.0, -56.0},{-91.0, 73.0, 51.0, 68.0, 96.0, 49.0, 10.0, -13.0, -6.0, -23.0, 50.0, -89.0, 19.0, -67.0, 36.0, -97.0, 0.0, 3.0, 1.0, 39.0},{53.0, 66.0, 23.0, 10.0, -33.0, 62.0, -73.0, 22.0, -65.0, 37.0, -83.0, -65.0, 59.0, -51.0, -56.0, 98.0,-57.0, -11.0, -48.0, 88.0},{83.0, 48.0, 67.0, 27.0, 91.0, -33.0, -90.0, -34.0, 39.0, -36.0, -68.0, 17.0, -7.0, 14.0, 11.0, -10.0, 96.0, 98.0, -32.0, 56.0},{52.0, -52.0, -5.0, 19.0, -25.0, 15.0, -1.0, -11.0, 8.0, -70.0, -4.0, -7.0, -4.0, -6.0, 48.0, 88.0, 13.0, -56.0, 85.0, -65.0}};
double b[][]={{-65.0, -11.0, 76.0, 78.0, 30.0, 93.0, -86.0, -99.0, -37.0, 52.0, -20.0, -10.0, -97.0, -71.0, 16.0, 9.0, -99.0, -84.0, 90.0, -18.0, -94.0},
{59.0, 67.0, 49.0, -45.0, 52.0, -33.0, -34.0, 29.0, -39.0, -80.0, 22.0, 7.0, 3.0, -19.0, -15.0, 7.0, -83.0, -4.0, 84.0 -60.0, -4.0},
{21.0, -23.0, -80.0, 86.0, 86.0, -30.0, 39.0, -73.0, -91.0, 5.0, 83.0, -2.0, -45.0, -54.0, -81.0, -8.0, 14.0, 83.0, 73.0, 45.0, 32.0},
{-91.0, -75.0, 20.0, -64.0, -15.0, 17.0, -89.0, 36.0, -49.0, -2.0, 56.0, -6.0, 76.0, 56.0, 2.0, -68.0, -59.0, -70.0, 48.0, 2.0, 24.0},
{-79.0, 99.0, -31.0, -8.0, -67.0, -72.0, -43.0, -55.0, 76.0, -57.0, 1.0, -58.0, 3.0,-59.0, 30.0, 32.0, 57.0, 29.0, 66.0, 50.0, -80.0},
{-89.0, -35.0, -55.0, 75.0, 15.0, -6.0, -53.0, -56.0, -96.0, 87.0, -90.0, -93.0, 52.0, -86.0, -38.0, -55.0, -53.0, 94.0, 98.0, 4.0,-79.0},
{-76.0, 45.0, 74.0, 12.0, -12.0, -69.0, 2.0, 71.0, 75.0, -60.0, -50.0, 23.0, 0.0, 6.0, 44.0, -82.0, 37.0, 91.0, 84.0, -15.0, -63.0},
{-50.0, -88.0, 93.0, 68.0, 10.0, -13.0, 84.0, -21.0, 65.0, 14.0, 4.0, 92.0, 11.0, 67.0, -18.0, -51.0, 4.0, 21.0, -38.0, 75.0, -59.0},
{-23.0, -95.0, 99.0, 62.0, -37.0, 96.0, 27.0, 69.0, -64.0,-92.0, -12.0, 87.0, 93.0, -19.0, -99.0, -92.0, -34.0, -77.0, 17.0, -72.0, 29.0},
{-5.0, -57.0, -30.0, -6.0, -96.0, 75.0, 25.0, -6.0, 96.0, 77.0, -35.0, -10.0, 82.0, 82.0, 97.0, -39.0, -65.0, -8.0, 34.0, 72.0, 65.0},
{85.0, -9.0, -14.0, 27.0, -45.0, 70.0, 55.0, 26.0, -87.0, -98.0, -25.0, -12.0, 60.0, -45.0, -24.0, -42.0, -88.0, -46.0, -95.0, 53.0, 28.0},
{80.0, -47.0, 38.0, -6.0, 43.0, -59.0, 91.0, -41.0, 90.0, -63.0, 11.0, -54.0, 33.0, -61.0, 74.0, 96.0, 21.0, -77.0, -58.0, -75.0, -9.0},
{-66.0, -98.0, -4.0,96.0, -11.0, 88.0, -99.0, 5.0, 5.0, 58.0, -53.0, 52.0, -98.0, -97.0, 50.0, 49.0, 97.0, -62.0, 79.0, -10.0, -80.0},
{80.0, -95.0, 82.0, 5.0, -68.0, -54.0, 64.0, -2.0, 5.0, 10.0, 85.0, -33.0, -54.0, -30.0, -65.0, 58.0, 40.0, -21.0, -84.0, -66.0, -11.0},
{94.0, 85.0, -31.0, 37.0, -25.0, 60.0, 55.0, -13.0, 48.0, -23.0, -50.0, 84.0, -71.0, 54.0, 47.0, 18.0, -67.0, -30.0, 5.0, -46.0, 53.0},
{-29.0, 54.0, -10.0, -68.0, -54.0, -24.0, -16.0, 21.0, 32.0, 33.0, -27.0, 48.0, 37.0, -61.0, 97.0, 45.0, -90.0, 87.0, -95.0, 85.0, 67.0},
{76.0, -11.0, -48.0, 38.0, -7.0, 86.0, -55.0, 51.0, 26.0, 8.0, -96.0, 99.0, 69.0, -84.0, 41.0, 78.0, -53.0, 4.0, 29.0, 38.0, 16.0},
{-8.0, 48.0, 95.0, 47.0, 39.0, -11.0, -72.0, -95.0, -17.0, 33.0, 65.0, 96.0, -52.0, -17.0, -22.0, -15.0, -91.0, -41.0, -16.0, 23.0, 14.0},
{92.0, 87.0, 63.0, -63.0, -80.0, 96.0, -62.0, 71.0, -58.0, 17.0, -89.0, -35.0, -96.0, -79.0, 7.0, 46.0, -74.0, 88.0, 93.0, -44.0, 52.0},
{-21.0, 35.0, 16.0, -17.0, 54.0, -22.0, -93.0, 27.0, 88.0, 0.0, -67.0, 94.0, -24.0, -30.0, -90.0, -5.0, -48.0, 45.0, -90.0, 32.0, -81.0},
{-86.0, 31.0, -80.0, -79.0, -5.0, 11.0, -20.0, 9.0, 52.0, -38.0, 67.0, 64.0, -49.0, 23.0, -86.0, 39.0, -97.0, 76.0, 10.0, 81.0, 20.0}};


double alfa[]={-2.7910,2.5623,-1.0429,0.5097,-2.8096,1.1883,2.0771,-2.9926,0.0715,0.4142,-2.5010,1.7731,1.6473,0.4934,2.1038,-1.9930,0.3813,-2.2144,-2.5572,2.9449};
int n=x.length;
double A[]=new double[x.length];
double B[]=new double[x.length];
double s1=0.0;
double s2=0.0;
for(int i=0;i<n;i++)
{s1=0.0;   
   for(int j=0;j<n;j++)
   {s1+=a[i][j]*Math.sin(alfa[j])+b[i][j]*Math.cos(alfa[j]);}
 A[i]=s1;
}    
for(int i=0;i<n;i++)
{s2=0.0;   
   for(int j=0;j<n;j++)
   {s2+=a[i][j]*Math.sin(x[j])+b[i][j]*Math.cos(x[j]);}
 B[i]=s2;
}
double s3=0.0;
for(int i=0;i<n;i++)
{s3+=(A[i]-B[i])*(A[i]-B[i]);}
return s3;
}
}


class f40 extends f_xj //Step function   f(x)=0   @x(-0.5,-0.5)   -5.0<x[i]<5.0
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;
for(int i=0;i<n;i++)
{s1+=Math.pow(Math.abs(x[i]+0.5),2.0);}
return s1;
}
}



class f41 extends f_xj //Penalized function   f(x)=0   @x(-1.0,-1.0)   -5.0<x[i]<5.0
{
public double u(double x,double a,double k,double m)
{
   double c=0.0;	
   	
     if(x>a){c=k*Math.pow(x-a,m);return c;}	
	  if((x>=-a)||(x<=a)){c=0;return c;}
	  if(x<-a){c=k*Math.pow(-x-a,m);return c;}
   
   return c;	
}	

public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;
double[] y=new double[n];
for(int i=0;i<n;i++)
{y[i]=(0.25*(x[i]+1.0))+1.0;}
s1=Math.pow(Math.sin(3.1415*y[0]),2.0)*10.0;

for(int i=0;i<n-1;i++)
{s1+=Math.pow((y[i]-1.0),2.0)*(10.0*Math.pow(Math.sin(3.1415*y[i+1]),2.0)+1.0);}
s1+=Math.pow((y[n-1]-1.0),2.0);
s1=s1*3.1415/(double)n;
double s2=0.0;
for(int i=0;i<n;i++)
{s2+=u(x[i],10.0,100.0,4.0);}
return s1+s2;
}
}

class f42 extends f_xj //Penalized2 function   f(x)=0   @x(1.0,1.0,....)   -5.0<x[i]<5.0
{
public double u(double x,double a,double k,double m)
{
   double c=0.0;	
   	
     if(x>a){c=k*Math.pow(x-a,m);return c;}	
	  if((x>=-a)||(x<=a)){c=0;return c;}
	  if(x<-a){c=k*Math.pow(-x-a,m);return c;}
   
   return c;	
}	

public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;

s1=Math.pow(Math.sin(3.1415*x[0]),2.0);

for(int i=0;i<n-1;i++)
{s1+=Math.pow((x[i]-1.0),2.0)*(Math.pow(Math.sin(3.0*3.1415*x[i+1]),2.0)+1.0);}
s1+=Math.pow((x[n-1]-1.0),2.0)*(Math.pow(Math.sin(2.0*3.1415*x[n-1]),2.0)+1.0);
s1=s1*0.1;
double s2=0.0;
for(int i=0;i<n;i++)
{s2+=u(x[i],5.0,100.0,4.0);}
return s1+s2;
}
}

class f43 extends f_xj //Shekel's Foxholes
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;

double[][] a={{-32.0,-16.0,0.0,16.0,32.0,-32.0,-16.0,0.0,16.0,32.0,-32.0,-16.0,0.0,16.0,32.0,-32.0,-16.0,0.0,16.0,32.0,-32.0,-16.0,0.0,16.0,32.0},{-32.0,-32.0,-32.0,-32.0,-32.0,-16.0,-16.0,-16.0,-16.0,-16.0,0.0,0.0,0.0,0.0,0.0,16.0,16.0,16.0,16.0,16.0,32.0,32.0,32.0,32.0,32.0}};


double sin=0.0;double sout=0.0;
for(int j=0;j<25;j++)
{   sin=0.0;
    for(int i=0;i<2;i++)
    {sin+=Math.pow((x[i]-a[i][j]),6.0);}	
	sout+=1.0/((double)j+sin);
}
return 1.0/(0.002+sout);
}
}

class f44 extends f_xj //Shekel's Foxholes
{
public double func(double x[]) 
{
double a[][] = {
	{9.681, 0.667, 4.783, 9.095, 3.517, 9.325, 6.544, 0.211, 5.122, 2.020},
	{9.400, 2.041, 3.788, 7.931, 2.882, 2.672, 3.568, 1.284, 7.033, 7.374},
	{8.025, 9.152, 5.114, 7.621, 4.564, 4.711, 2.996, 6.126, 0.734, 4.982},
	{2.196, 0.415, 5.649, 6.979, 9.510, 9.166, 6.304, 6.054, 9.377, 1.426},
	{8.074, 8.777, 3.467, 1.863, 6.708, 6.349, 4.534, 0.276, 7.633, 1.567},
	{7.650, 5.658, 0.720, 2.764, 3.278, 5.283, 7.474, 6.274, 1.409, 8.208},
	{1.256, 3.605, 8.623, 6.905, 4.584, 8.133, 6.071, 6.888, 4.187, 5.448},
	{8.314, 2.261, 4.224, 1.781, 4.124, 0.932, 8.129, 8.658, 1.208, 5.762},
	{0.226, 8.858, 1.420, 0.945, 1.622, 4.698, 6.228, 9.096, 0.972, 7.637},
	{7.305, 2.228, 1.242, 5.928, 9.133, 1.826, 4.060, 5.204, 8.713, 8.247},
	{0.652, 7.027, 0.508, 4.876, 8.807, 4.632, 5.808, 6.937, 3.291, 7.016},
	{2.699, 3.516, 5.874, 4.119, 4.461, 7.496, 8.817, 0.690, 6.593, 9.789},
	{8.327, 3.897, 2.017, 9.570, 9.825, 1.150, 1.395, 3.885, 6.354, 0.109},
	{2.132, 7.006, 7.136, 2.641, 1.882, 5.943, 7.273, 7.691, 2.880, 0.564},
	{4.707, 5.579, 4.080, 0.581, 9.698, 8.542, 8.077, 8.515, 9.231, 4.670},
	{8.304, 7.559, 8.567, 0.322, 7.128, 8.392, 1.472, 8.524, 2.277, 7.826},
	{8.632, 4.409, 4.832, 5.768, 7.050, 6.715, 1.711, 4.323, 4.405, 4.591},
	{4.887, 9.112, 0.170, 8.967, 9.693, 9.867, 7.508, 7.770, 8.382, 6.740},
	{2.440, 6.686, 4.299, 1.007, 7.008, 1.427, 9.398, 8.480, 9.950, 1.675},
	{6.306, 8.583, 6.084, 1.138, 4.350, 3.134, 7.853, 6.061, 7.457, 2.258},
	{0.652, 2.343, 1.370, 0.821, 1.310, 1.063, 0.689, 8.819, 8.833, 9.070},
	{5.558, 1.272, 5.756, 9.857, 2.279, 2.764, 1.284, 1.677, 1.244, 1.234},
	{3.352, 7.549, 9.817, 9.437, 8.687, 4.167, 2.570, 6.540, 0.228, 0.027},
	{8.798, 0.880, 2.370, 0.168, 1.701, 3.680, 1.231, 2.390, 2.499, 0.064},
	{1.460, 8.057, 1.336, 7.217, 7.914, 3.615, 9.981, 9.198, 5.292, 1.224},
	{0.432, 8.645, 8.774, 0.249, 8.081, 7.461, 4.416, 0.652, 4.002, 4.644},
	{0.679, 2.800, 5.523, 3.049, 2.968, 7.225, 6.730, 4.199, 9.614, 9.229},
	{4.263, 1.074, 7.286, 5.599, 8.291, 5.200, 9.214, 8.272, 4.398, 4.506},
	{9.496, 4.830, 3.150, 8.270, 5.079, 1.231, 5.731, 9.494, 1.883, 9.732},
	{4.138, 2.562, 2.532, 9.661, 5.611, 5.500, 6.886, 2.341, 9.699, 6.500}};
	
	double c[] = {0.806,0.517,0.100,0.908,0.965,0.669,0.524,0.902,0.531,0.876,0.462,0.491,0.463,0.714,0.352,0.869,0.813,0.811,0.828,0.964,0.789,0.360,0.369,0.992,0.332,0.817,0.632,0.883,0.608,0.326};
	int dimension=x.length;
	double sum=0.0;
	double h=0.0;
	double sp=0.0;
	for (int j=0; j<30; j++)
	{
		sp=0.0;
		for (int i=0; i<dimension; i++)
		{
			h=(x[i])-a[j][i];
			sp+=h*h;
		}
		sum-=1.0/(sp+c[j]);
	}
	
	
	return sum;
}
}

class f45 extends f_xj //Exp2 function   f(x)=0   @x(1.0,10.0)   0.0<x[i]<20.0
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;
for(int i=0;i<10;i++)
{s1+=Math.pow((Math.exp(-(double)i*x[0]/10.0)-(5.0*Math.exp(-(double)i*x[1]/10.0))-Math.exp(-(double)i/10.0)+5.0*Math.exp(-(double)i)),2.0);}
return s1;
}
}

class f46 extends f_xj //Stretched V function   
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;
for(int i=0;i<=n-2;i++)
{s1+=Math.pow((x[i+1]*x[i+1]+x[i]*x[i]),0.25)*Math.sin(50.0*Math.pow((x[i+1]*x[i+1]+x[i]*x[i]),0.1))+1.0;}
return s1;
}
}

class f47 extends f_xj //Trecanni function   f(x)=0   @x(0.0,0.0,....)   -5.0<x[i]<5.0
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;
s1=Math.pow(x[0],4.0)+4.0*Math.pow(x[0],3.0)+4.0*Math.pow(x[0],2.0)+x[1]*x[1];
return s1;
}
}

class f48 extends f_xj //Trefethen4 function   f(x)=-3.306868   @x(-0.0244031,0.2106124)   -6.5<x[0]<6.5    -4.5<x[1]<4.5                  
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;
s1=Math.exp(Math.sin(50.0*x[0]))+Math.sin(60.0*Math.exp(x[1]))+Math.sin(70.0*Math.sin(x[0]))+Math.sin(Math.sin(80.0*x[1]))-Math.sin(10.0*(x[0]+x[1]))+1.0/4.0*(x[0]*x[0]+x[1]*x[1]);
return s1;
}
}

class f49 extends f_xj //Paviani function                    
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;double fact=1.0;
for(int i=0;i<=n-1;i++)
{s1+=Math.pow(Math.log(x[i]-2.0),2.0)+Math.pow(Math.log(10.0-x[i]),2.0);}
for(int i=0;i<=n-1;i++)
{fact*=x[i];}
fact=Math.pow(fact,0.2);
return s1-fact;
}
}

class f50 extends f_xj //McCormick function      -1.5<=x[0]<=4 , -3.0<=x[1]<=4    f(x)=-1.9133  @x(-0.547,-1.54719)            
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	

double s1=Math.sin(x[0]+x[1])+Math.pow(x[0]-x[1],2.0)-1.5*x[0]+2.5*x[1]+1.0;
return s1;
}
}

class f51 extends f_xj //Leon function     f(x)=0.0  @x(1.0,1.0)           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	

double s1=100.0*(x[1]-x[0]*x[0]*x[0])*(x[1]-x[0]*x[0]*x[0])+(x[0]-1.0)*(x[0]-1.0);
return s1;
}
}

class f552 extends f_xj //Hosaki function     f(x)=-2.3458  @x(4.0,2.0) Error!!!!           
{
public double func(double x[]) 
{
int DD=x.length; 
double sum=0.0;
for(int i=0;i<DD-1;i++)
{sum+=x[i]*x[i]+2.0*x[i+1]*x[i+1]-0.3*Math.cos(3.0*Math.PI*x[i])-0.4*Math.cos(4.0*Math.PI*x[i+1])+0.7;}

return sum;
}
}


class f553 extends f_xj //Deb01           
{
public double func(double x[]) 
{
int DD=x.length; 
double sum=0.0;
for(int i=0;i<DD;i++)
{sum+=x[i]*x[i];}

return -Math.exp(-0.5*sum);
}
}


class f554 extends f_xj //zerosum           
{
public double func(double x[]) 
{
int DD=x.length; 
double sum=0.0;
for(int i=0;i<DD;i++)
{sum+=x[i];}
double ret;
if(sum==0.0)
{ret=0.0;}
else
{ret=1.0+Math.sqrt(10000*Math.abs(sum));} 

return ret;
}
}


class f53 extends f_xj //Hansen function     f(x)=-176.54  @x(-1.30,-1.42)           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double s1=0.0;double s2=0.0;
for(int i=0;i<=4;i++)
{s1+=((double)i+1.0)*Math.cos((double)i*x[0]+(double)i+1.0);}
for(int j=0;j<=4;j++)
{s2+=((double)j+1.0)*Math.cos(((double)j+2.0)*x[1]+(double)j+1.0);}
return s1*s2;
}
}

class f54 extends f_xj //Gear function     f(x)=0.0  @x(16,19,43,49)  12<=x[i]<=60           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	

double s1=Math.pow((1.0/6.931-(x[0]*x[1])/(x[2]*x[3])),2.0);
return s1;
}
}

class f55 extends f_xj //Gear function     f(x)=0.0  @x(16,19,43,49)  12<=x[i]<=60           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double s1=0.0;int n=x.length;
for(int i=0;i<=n-2;i++)
{s1+=-(x[i+1]+47.0)*Math.sin(Math.sqrt(Math.abs(x[i+1]+0.5*x[i]+47.0)))+ Math.sin(Math.sqrt(Math.abs(x[i]-(x[i+1]+47.0))))*(-x[i]);}

return s1;
}
}

class f56 extends f_xj //Chichinadze function     f(x1, x2) = f(5.90133, 0.5) = -43.3159.  -30<=x[i]<=30           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double s1=x[0]*x[0]-12.0*x[0]+11.0+10.0*Math.cos(x[0]*3.1415/2.0)+8.0*Math.sin(5.0*3.1415*x[0])-((1.0/Math.sqrt(5.0))*Math.exp(-(x[1]-0.5)*(x[1]-0.5)/2.0));

return s1;
}
}

class f57 extends f_xj //Zettl function     f(x1, x2) = f(-0.02990, 0.0) = -0.003791.  -30<=x[i]<=30           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double s1=Math.pow((x[0]*x[0]+x[1]*x[1]-2.0*x[0]),2.0)+0.25*x[0];
return s1;
}
}

class f58 extends f_xj //Plateau function     f(x1, x2) = f(0.0, 0.0,0.0,0.0,0.0) = 30.0  -5.12<=x[i]<=5.12           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;
for(int i=0;i<n;i++)
{s1+=Math.abs(x[i]);}
return s1+30.0;

}
}


class f59 extends f_xj //Xin She Yang function1     f(x) = f(0.0, 0.0,0.0,0.0,0.0,....) = 0.0  -2pi<=x[i]<=2pi           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;double s2=0.0;
for(int i=0;i<n;i++)
{s1+=Math.abs(x[i]);}
for(int i=0;i<n;i++)
{s2+=-Math.sin(x[i]*x[i]);}
return s1*Math.exp(-s2);
}
}

class f60 extends f_xj //     f(x) = f(1.0,0.5,0.333,...) = 0.0  -5<=x[i]<=5           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;
for(int i=0;i<n;i++)
{s1+=Math.random()*Math.abs(x[i]-(1.0/((double)i+1.0)));}
return s1;
}
}

class f61 extends f_xj //              
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int n=x.length;double s1=0.0;double s2=0.0;double s3=0.0;
for(int i=0;i<n;i++)
{s1+=Math.sin(x[i])*Math.sin(x[i]);}
for(int i=0;i<n;i++)
{s2+=x[i]*x[i];}
double c1=(s1-Math.exp(-s2));
for(int i=0;i<n;i++)
{s3+=Math.pow(Math.sin(Math.sqrt(Math.abs(x[i]))),2.0);}
return c1*Math.exp(-s3);
}
}

class f62 extends f_xj // Yang funtion     x(pi,pi)             
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double alfa=1.0;
double beta=1.0;
int K=10;
double s1=0.0;
for(int j=0;j<K;j++)
{
  for(int i=0;i<K;i++)
  {
  s1+=Math.random()*Math.exp(-alfa*((x[0]-(double)i)*(x[0]-(double)i)+(x[1]-(double)j)*(x[1]-(double)j)));	  
  }	
	
}
double s2=-5.0*Math.exp(-beta*((x[0]-3.1415)*(x[0]-3.1415)+(x[1]-3.1415)*(x[1]-3.1415)));	

return s2-s1;

}
}


class f665 extends f_xj // Weierstrass Function             
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double a=0.5;double b=3.0;
int kmax=20;
double suminner=0.0;
double sumouter=0.0;

for(int i=0;i<DD;i++)
{   
	suminner=0.0;
	for(int k=0;k<kmax;)
	{
	suminner+=(Math.pow(a,(double)k)*Math.cos(2.0*Math.PI*Math.pow(b,(double)k)*(x[i]+0.5)));
 	}
sumouter+=suminner; 
}

double suminner1=0.0;
for(int k=0;k<kmax;k++)
{suminner1+=Math.pow(a,(double)k)*Math.cos(2.0*Math.PI*Math.pow(b,(double)k)*0.5);}
return sumouter-(double)DD*suminner1;

}

}



class f666 extends f_xj // Hgbat func            
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+=x[i]*x[i];}
double sum11=sum1*sum1;

double sum2=0.0;
for(int i=0;i<DD;i++)
{sum2+=x[i];}
double sum22=sum2*sum2;

double sum1122=Math.sqrt(Math.abs(sum11-sum22))+((0.5*sum1+sum2)/(double)DD)+0.5;

return sum1122;

}

}



class f667 extends f_xj // HappyCat Function            
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+=x[i]*x[i];}
double sum11=sum1*sum1;

double sum2=0.0;
for(int i=0;i<DD;i++)
{sum2+=x[i];}
double sum22=sum2*sum2;

double sum1122=Math.pow(Math.abs(sum1-(double)DD),0.25)+((0.5*sum1+sum2)/(double)DD)+0.5;

return sum1122;

}

}


class f668 extends f_xj // Katsuura Function  ++           
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double sumin1=0.0;
double powerin=1.0;

for(int i=0;i<DD;i++)
{  
  sumin1=0.0;	
  for(int j=1;j<=32;j++)
  {sumin1+=Math.abs(Math.pow(2.0,j)*x[i]-Math.round(Math.pow(2.0,j)*x[i]))/Math.pow(2.0,j);}

  powerin*=Math.pow((1.0+sumin1*(double)(i+1)),(10.0/Math.pow((double)DD,1.2)));
}
return (10.0/(double)DD/(double)DD)*powerin-(10.0/(double)DD/(double)DD)+200;

}

}


class f669 extends f_xj // Griewank�s plus Rosenbrock�s Function          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] f10=new double[DD];
for(int i=0;i<DD-1;i++)
{f10[i]=100*(x[i]*x[i]-x[i+1])*(x[i]*x[i]-x[i+1])+(x[i]-1)*(x[i]-1);} 
f10[DD-1]=100*(x[DD-1]*x[DD-1]-x[0])*(x[DD-1]*x[DD-1]-x[0])+(x[DD-1]-1)*(x[DD-1]-1);

double sum1=0.0;
double sum2=0.0;
for(int i=0;i<DD;i++)
{sum1+=f10[i]*f10[i]/4000.0;}
double fact=1.0;
for(int i=0;i<DD;i++)
{fact*=Math.cos(f10[i]/Math.sqrt((double)i+1));}

return sum1-fact+1;


}

}




class f670 extends f_xj // Expanded Scaffer�s F6 Function         
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] f10=new double[DD];
for(int i=0;i<DD-1;i++)
{f10[i]=0.5+(Math.sin(Math.sqrt(x[i]*x[i]+x[i+1]*x[i+1]))*Math.sin(Math.sqrt(x[i]*x[i]+x[i+1]*x[i+1]))-0.5)/((1.0+0.001*(x[i]*x[i]+x[i+1]*x[i+1]))*(1.0+0.001*(x[i]*x[i]+x[i+1]*x[i+1])))             ;} 
f10[DD-1]=0.5+(Math.sin(Math.sqrt(x[DD-1]*x[DD-1]+x[0]*x[0]))*Math.sin(Math.sqrt(x[DD-1]*x[DD-1]+x[0]*x[0]))-0.5)/((1.0+0.001*(x[DD-1]*x[DD-1]+x[0]*x[0]))*(1.0+0.001*(x[DD-1]*x[DD-1]+x[0]*x[0])));

double sum1=0.0;
double sum2=0.0;
for(int i=0;i<DD;i++)
{sum1+=f10[i];}
 
return sum1;


}

}



class f671 extends f_xj // Modified Schwefel�s Function         
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] f10=new double[DD];
double[] z=new double[DD]; 
double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{z[i]=x[i]+4.209687462275036*100.0;}

for(int i=0;i<DD;i++)
{
     if(Math.abs(z[i])<=500.0)
     {gz[i]=z[i]*Math.sin(Math.sqrt(Math.abs(z[i])));}
	 else if(z[i]>500.0)
	 {gz[i]=(500.0-(z[i]%500.0))*Math.sin(Math.sqrt(Math.abs(500.0-(z[i]%500.0)))) - (((z[i]-500.0)*(z[i]-500.0))/(10000.0*(double)DD)) ;} 	
	 else if(z[i]<-500.0)
	 {gz[i]=((Math.abs(z[i])%500.0)-500.0)*Math.sin(Math.sqrt((Math.abs(z[i])%500.0)-500.0))- (((z[i]+500.0)*(z[i]+500.0))/(10000.0*(double)DD)) ;                }
}

for(int i=0;i<DD;i++)
{sum1+=gz[i];}
return 418.9829*(double)DD-sum1;
}

}


class f672 extends f_xj // Expanded Two-Peak Trap        
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] y=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{y[i]=x[i]+20.0;}

for(int i=0;i<DD;i++)
{
    if(y[i]<0)
    {t[i]=-160+y[i]*y[i];}
    else if((0.0<=y[i])&&(y[i]<=15.0))
    {t[i]=160.0/15.0*(y[i]-15.0);}
    else if((15.0<=y[i])&&(y[i]<=20.0))
    {t[i]=200.0/5.0*(-y[i]+15.0);}
    else if(y[i]>20.0)
    {t[i]=-200.0+(y[i]-20.0)*(y[i]-20.0);}
    	
}

for(int i=0;i<DD;i++)
{sum1+=t[i];}

return sum1+200*DD;


}

}



class f673 extends f_xj // Expanded Five-Uneven-Peak Trap      
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] y=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

 

for(int i=0;i<DD;i++)
{
    if(x[i]<0)
    {t[i]=-200+x[i]*x[i];}
    else if((0.0<=x[i])&&(x[i]<2.5))
    {t[i]=-80.0*(2.5-x[i]);}
    else if((2.5<=x[i])&&(x[i]<5.0))
    {t[i]=-64.0*(x[i]-2.5);}
    else if((5.0<=x[i])&&(x[i]<7.5))
    {t[i]=-64.0*(7.5-x[i]);}
    else if((7.5<=x[i])&&(x[i]<12.5))
    {t[i]=-28.0*(x[i]-7.5);}
    else if((12.5<=x[i])&&(x[i]<17.5))
    {t[i]=-28.0*(17.5-x[i]);}  
    else if((17.5<=x[i])&&(x[i]<22.5))
    {t[i]=-32.0*(x[i]-17.5);}  	
    else if((22.5<=x[i])&&(x[i]<27.5))
    {t[i]=-32.0*(27.5-x[i]);} 
    else if((27.5<=x[i])&&(x[i]<=30.0))
    {t[i]=-80.0*(x[i]-27.5);} 
    else if(x[i]>30.0)
    {t[i]=-200.0+(x[i]-30.0)*(x[i]-30.0);}
}

for(int i=0;i<DD;i++)
{sum1+=t[i];}

return sum1+200*DD;


}

}



class f674 extends f_xj // Expanded Equal Minima      
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] y=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{y[i]=x[i]+0.1;} 

for(int i=0;i<DD;i++)
{
    if((y[i]<0)||(y[i]>1))
    {t[i]=y[i]*y[i];}
    else if((0.0<=y[i])&&(y[i]<=1.0))
    {t[i]=-Math.pow(Math.sin(5.0*Math.PI*y[i]),6.0);}
 
}

for(int i=0;i<DD;i++)
{sum1+=t[i];}

return sum1+DD;


}

}
class f675 extends f_xj // Expanded Decreasing Minima   
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] y=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{y[i]=x[i]+0.1;} 

for(int i=0;i<DD;i++)
{
    if((y[i]<0)||(y[i]>1))
    {t[i]=y[i]*y[i];}
    else if((0.0<=y[i])&&(y[i]<=1.0))
    {t[i]=-Math.exp(-2.0*Math.log(2.0)*((y[i]-0.1)/0.8)*((y[i]-0.1)/0.8))*Math.pow(Math.sin(5.0*Math.PI*y[i]),6.0);}
 
}

for(int i=0;i<DD;i++)
{sum1+=t[i];}

return sum1+DD;


}

}


class f676 extends f_xj // Expanded Uneven Minima   
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] y=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{y[i]=x[i]+ 0.079699392688696;} 

for(int i=0;i<DD;i++)
{
    if((y[i]<0)||(y[i]>1))
    {t[i]=y[i]*y[i];}
    else if((0.0<=y[i])&&(y[i]<=1.0))
    {t[i]=-Math.pow(Math.sin(5.0*Math.PI*(Math.pow(y[i],0.75)-0.05)),6.0);}
 
}

for(int i=0;i<DD;i++)
{sum1+=t[i];}

return sum1-DD;


}

}




class f677 extends f_xj // Expanded Himmelblau's Function 
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] y=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{
   if((double)i%2==1)
   {y[i]=x[i]-3.0;}	
   else if((double)i%2==0)
   {y[i]=x[i]-2.0;}

}

for(int i=0;i<DD-1;i=i+2)
{sum1+= ((y[i]*y[i]+y[i+1]-11.0)*(y[i]*y[i]+y[i+1]-11.0))+((y[i]+y[i+1]*y[i+1]-7.0)*(y[i]+y[i+1]*y[i+1]-7.0));                  } 

 

return sum1;


}

}



class f678 extends f_xj // Modified Vincent Function 
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] y=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{y[i]=x[i]+4.1112;}

for(int i=0;i<DD;i++)
{
   if((0.25<=y[i])&&(y[i]<=10.0))
   {t[i]=Math.sin(10.0*Math.log10(y[i]));}	
   else if (y[i]<0.25)
   {t[i]=(0.25-y[i])*(0.25-y[i])+Math.sin(10.0*Math.log10(2.5));}
   else if (y[i]>10.0)
   {t[i]=(-10.0+y[i])*(-10.0+y[i])+Math.sin(10.0*Math.log10(10.0));}    	
	
	
}

for(int i=0;i<DD;i++)
{sum1+=(t[i]+0.1);}
sum1=sum1/(double)DD; 
 

return sum1;


}

}



 



class f679 extends f_xj // Shifted Sphere Function 
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{z[i]=x[i]-1.0;}

for(int i=0;i<DD;i++)
{sum1+=z[i]*z[i];}

sum1=sum1-450;
 

return sum1;


}

}




class f680 extends f_xj // Shifted Rastrigin�s Function 
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{z[i]=x[i]-1.0;}

for(int i=0;i<DD;i++)
{sum1+=z[i]*z[i]-10.0*Math.cos(2.0*Math.PI*z[i])+10.0;}

sum1=sum1-330;
 

return sum1;


}

}


class f681 extends f_xj // Shifted Griewank�s Function 
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{z[i]=x[i]-1.0;}

for(int i=0;i<DD;i++)
{sum1+=z[i]*z[i]/4000.0;}

double fakt=1.0;

for(int i=0;i<DD;i++)
{fakt*=Math.cos(z[i]/(Math.sqrt(i+1)));}

double ret=sum1-fakt+1-180;
//sum1=sum1-330;
 

return ret;


}

}


class f682 extends f_xj // Shifted Ackley�s Function 
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;
double sum2=0.0;
for(int i=0;i<DD;i++)
{z[i]=x[i]-1.0;}

for(int i=0;i<DD;i++)
{sum1+=z[i]*z[i];}
double part1=-20.0*Math.exp(-0.2*Math.sqrt(sum1/(double)DD));

for(int i=0;i<DD;i++)
{sum2+=Math.cos(2.0*Math.PI*z[i]);}
sum2=sum2/(double)DD;
double part2=Math.exp(sum2);
 
double ret=part1-part2+20.0+Math.exp(1)-140.0;

 
//sum1=sum1-330;
 

return ret;


}

}


class f690 extends f_xj // AckleyN4
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD-1;i++)
{sum1+= Math.exp(-0.2)*Math.sqrt(x[i]*x[i]+x[i+1]*x[i+1])+3.0*(Math.cos(2.0*x[i])+Math.sin(2.0*x[i+1]));}

return sum1;


}

}


class f691 extends f_xj 
{// AlpineN2
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=1.0;

for(int i=0;i<DD;i++)
{sum1*= Math.sqrt(x[i])*Math.sin(x[i]);}

return sum1;


}

}



class f692 extends f_xj 
{// Exponential
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{sum1+= x[i]*x[i];}

return -Math.exp(-0.5*sum1);


}

}


class f693 extends f_xj 
{// Periodic
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{sum1+= x[i]*x[i];}

double sum2=0.0;

for(int i=0;i<DD;i++)
{sum2+= Math.pow(Math.sin(x[i]),2.0);}


return 1+sum2-0.1*Math.exp(sum1);


}

}




class f694 extends f_xj 
{// Qing
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{sum1+= (x[i]*x[i]-(i+1))*(x[i]*x[i]-(i+1));}

return sum1;


}

}




class f695 extends f_xj 
{// Quartic
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{sum1+= (i+1)*Math.pow(x[i],4.0);}

return sum1+Math.random();


}

}



class f696 extends f_xj 
{// Ridge
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=1;i<DD;i++)
{sum1+= x[i]*x[i];}
sum1=Math.sqrt(sum1);
return x[0]+sum1;


}

}



class f697 extends f_xj 
{// Schwefel 2.20
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{sum1+= Math.abs(x[i]);}
 
return  sum1;


}

}



class f698 extends f_xj 
{// Shubert 3 
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{
	for(int j=1;j<=5;j++)
	{sum1+=j*Math.sin(x[i]*(j+1)+j) ;}

}
 
return  sum1;


}

}



class f699 extends f_xj 
{// Shubert 4 
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum1=0.0;

for(int i=0;i<DD;i++)
{
	for(int j=1;j<=5;j++)
	{sum1+=j*Math.cos(x[i]*(j+1)+j) ;}

}
 
return  sum1;


}

}



class f700 extends f_xj 
{// rana
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double t1, t2, sum;
sum = 0.0;
for (int i = 0; i < DD-1; i++) {
t1 = Math.sqrt(Math.abs(x[i+1] + x[i] + 1.0));
t2 = Math.sqrt(Math.abs(x[i+1] - x[i] + 1.0));
sum += (x[i+1] + 1.0) * Math.cos(t2) * Math.sin(t1) + Math.cos(t1) * Math.sin(t2) * x[i];
}
return sum;


}

}




class f701 extends f_xj 
{// eggholder
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double[] z=new double[DD];
double[] t=new double[DD]; 
//double[] gz=new double[DD];

double sum;
sum = 0.0;
for (int i = 0; i < DD-1; i++) {
sum += -(x[i+1] + 47.0) * Math.sin(Math.sqrt(Math.abs(x[i+1] + x[i] * 0.5 + 47.0))) +Math.sin(Math.sqrt(Math.abs(x[i] - (x[i+1] + 47.0)))) * (-x[i]);
}
return sum;



}

}



class f702 extends f_xj 
{// maxmod
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
 
double t = x[0];
double u=0.0; 
for (int i = 1; i < DD; i++) {
u = Math.abs(x[i]);
if (u < t) t = u;
 
}
return u;
}

}




class f703 extends f_xj 
{// Michalewitz
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;

double u;
int i;
u=0;
for (i=0;i<DD;i++) {
u = u + Math.sin(x[i])* Math.pow(Math.sin((i+1)*x[i]*x[i]/Math.PI), 2.0 * 10.0);
}
return(-u);

}

}


class f704 extends f_xj 
{// Multimod
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;

double t, s, p;
s = p = Math.abs(x[0]);
for (int i = 1; i < DD; i++) {
t = Math.abs(x[1]);
s += t;
p *= t;
}
return s + p;

}

}




class f705 extends f_xj 
{// Trid
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double sum1=0.0;
double sum2=0.0;
for(int i=0;i<DD;i++)
{sum1+=(x[i]-1.0)*(x[i]-1.0);} 
 for(int i=1;i<DD;i++)
{sum2+=x[i]*x[i-1];} 
 
return sum1-sum2;
}

}



class f706 extends f_xj 
{// Plateau
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
int i;
double sum = 0.0;
for (i = 0; i < 5; i++) {
sum += Math.floor(x[i]);
}
return 30.0 + sum;
 
 
}

}



class f707 extends f_xj 
{// Paviani
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
double a,b,sum=0.0, mul=1.0 ;
int i;
for (i=0 ; i<DD ; i++) {
a=Math.log(x[i]-2.0) ; b=Math.log(10.0-x[i]) ;
sum+= a*a + b*b ;
mul*= x[i] ;
}
return sum - Math.pow(mul,0.2) ;

}

}



class f708 extends f_xj 
{//Schwefel1_2
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
int DD=x.length;
int i, j;
double sum, sum1;
sum = 0.0;
for (i = 0; i < DD; i++) {
sum1 = 0.0;
for (j = 0; j < i; j++) {
sum1 += x[i];
}
sum += sum1 * sum1;
}
return sum;
}

}


class f709 extends f_xj 
{//Schwefel2_26
public double func(double x[]) 
{
int DD=x.length;
int i;
double sum;
sum = 0.0;
for (i = 0; i < DD; i++) {
sum += x[i] * Math.sin(Math.sqrt(Math.abs(x[i])));
}
return -sum;

}

}



class f710 extends f_xj 
{//STYBLINSKI-TANG
public double func(double x[]) 
{
int DD=x.length;
int i;
double sum;
sum = 0.0;
for (i = 0; i < DD; i++) {
sum += Math.pow(x[i],4.0)-16.0*x[i]*x[i]+5.0*x[i] ;
}
return 0.5*sum;

}

}


class f711 extends f_xj 
{//Step
public double func(double x[]) 
{
int DD=x.length;
int i;
double y;
double sum;
sum = 0.0;
for (i = 0; i < DD; i++) {
y = Math.floor(x[i] + 0.5);
sum += y*y;
}
return sum;

}

}





class f712 extends f_xj 
{//L (or F2) Function
public double func(double x[]) 
{
int DD=x.length;
 
double k=6.0;
double l1=5.1;
double l2=0.5;
double l3=4.0*Math.log(2.0);
double l4=0.066832364099628;
double l5=0.64;


double sum;
sum = 0.0;
for (int i = 0; i < DD; i++) {
sum+=Math.pow(Math.sin(l1*Math.PI*x[i]+l2),k)*Math.exp(-l3*((x[i]-l4)/l5)*((x[i]-l4)/l5));
}
return -sum;

}

}


 

class f713 extends f_xj 
{//M (or Hyper-Grid) Function
public double func(double x[]) 
{
int DD=x.length;
 
double k=6.0;
double l1=5.0;
double l2=0.5;
double l3=4.0*Math.log(2.0);
double l4=0.066832364099628;
double l5=0.64;


double sum;
sum = 1.0;
for (int i = 0; i < DD; i++) {
sum*=Math.pow(Math.sin(l1*Math.PI*x[i]+l2),k);
}
return -sum/(double)DD;

}

}


class f714 extends f_xj 
{//Mishra Function1
public double func(double x[]) 
{
int DD=x.length;
 
double sum1=0.0;
for(int i=0;i<DD-1;i++)
{sum1+=x[i];}
double g1=(double)DD-sum1; 

return Math.pow(1+g1,g1);

}

}

class f715 extends f_xj 
{//Mishra Function2
public double func(double x[]) 
{
int DD=x.length;
 
double sum1=0.0;
for(int i=0;i<DD-1;i++)
{sum1+=(x[i]+x[i+1])*0.5;}
double g1=(double)DD-sum1; 

return Math.pow(1+g1,g1);

}

}



class f716 extends f_xj 
{//Mishra Function7
public double func(double x[]) 
{
int DD=x.length;
 
double sum2=1.0;
for(int i=1;i<=DD;i++)
{sum2*=i;}



double sum1=1.0;
for(int i=0;i<DD;i++)
{sum1*=(x[i]);}
 

return Math.pow(sum1-sum2,2.0);

}

}



class f717 extends f_xj 
{//Mishra Function11
public double func(double x[]) 
{
int DD=x.length;
 
double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+=Math.abs(x[i]);}

sum1=sum1/(double)DD;

double sum2=1.0;
for(int i=0;i<DD;i++)
{sum2*=Math.abs(x[i]);}
sum2=Math.pow(sum2,(1.0/(double)DD)); 

return Math.pow(sum1-sum2,2.0);

}

}

class f718 extends f_xj 
{//Moved-Axis Parallel Hyper-Ellipsoid Function
public double func(double x[]) 
{
int DD=x.length;
 
double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+=Math.pow(((i+1)*(x[i]-5.0*(i+1))),2.0);}
 
return sum1;

}

}


class f719 extends f_xj 
{//Lunacek's bi-Rastrigin Function
public double func(double x[]) 
{
int DD=x.length;
double d=1.0;
double mu1=2.5; 
double s = 1.0-(1.0/(2.0*Math.sqrt(22)-8.2));
double mu2=-Math.sqrt((mu1*mu1-d)/2);

double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+=(x[i]-mu1)*(x[i]-mu1);}

double first=sum1;

double sum2=0.0;
for(int i=0;i<DD;i++)
{sum2+=(x[i]-mu2)*(x[i]-mu2);}

double second=(d*(double)DD)+s*sum2;

double first_term=Math.min(first,second);

double sum3=0.0;
for(int i=0;i<DD;i++)
{sum3+=1.0-Math.cos(2.0*Math.PI*(x[i]-mu1));}

sum3=10*sum3;

return first_term+sum3;

}

}




class f720 extends f_xj 
{//Lunacek's bi-Sphere Function
public double func(double x[]) 
{
int DD=x.length;
double d=1.0;
double mu1=2.5; 
double s = 1.0-(1.0/(2.0*Math.sqrt(22)-8.2));
double mu2=-Math.sqrt((mu1*mu1-d)/2);

double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+=(x[i]-mu1)*(x[i]-mu1);}

double first=sum1;

double sum2=0.0;
for(int i=0;i<DD;i++)
{sum2+=(x[i]-mu2)*(x[i]-mu2);}

double second=(d*(double)DD)+s*sum2;

double first_term=Math.min(first,second);
 
return first_term;

}

}


class f721 extends f_xj 
{//Sinusoidal Function
public double func(double x[]) 
{
int DD=x.length;
double A=2.5;
double B=5.0;
double Z=30.0;

double sum1=1.0;
for(int i=0;i<DD;i++)
{sum1*=Math.sin(x[i]*(3.141592/180)-Z*(3.141592/180));}

double sum2=1.0;
for(int i=0;i<DD;i++)
{sum2*=Math.sin(B*(x[i]*(3.141592/180)-Z*(3.141592/180)));} 

return -(A*sum1+sum2);

}

}


class f722 extends f_xj 
{//Stepint Function
public double func(double x[]) 
{
int DD=x.length;
double A=2.5;
double B=5.0;
double Z=30.0;

double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+=Math.floor(x[i]);}

return 25+sum1;

}

}


class f723 extends f_xj 
{//Deflected Corrugated Spring Function
public double func(double x[]) 
{
int DD=x.length;
double alfa=5.0;
double k=5.0;


double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+= (x[i]-alfa)*(x[i]-alfa);}
double sum2=Math.sqrt(sum1);
return 0.1*sum1-Math.cos(k*sum2);

}

}



class f724 extends f_xj 
{//Xin-She Yang Function
public double func(double x[]) 
{
int DD=x.length;
double alfa=5.0;
double k=5.0;


double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+= Math.random()*Math.pow(Math.abs(x[i]),(i+1)) ;}
 
return sum1;

}

}


class f725 extends f_xj 
{//Xin-She Yang Function 2 
public double func(double x[]) 
{
int DD=x.length;
double alfa=5.0;
double k=5.0;


double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+= Math.abs(x[i]);}

double sum2=0.0;
for(int i=0;i<DD;i++)
{sum2+= Math.sin(x[i]*x[i]);}


return sum1*Math.exp(-sum2);

}

}




class f726 extends f_xj 
{//Xin-She Yang Function 3 
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;


double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+= Math.pow((x[i]/beta),2*m);}

double prod=1.0;
for(int i=0;i<DD;i++)
{prod*= Math.cos(x[i])*Math.cos(x[i]);}

double sum2=0.0;
for(int i=0;i<DD;i++)
{sum2+= (x[i]*x[i]);}


return Math.exp(-sum1)-2.0*Math.exp(-sum2)*prod;

}

}



class f727 extends f_xj 
{//Xin-She Yang Function 4 
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;


double sum1=0.0;
for(int i=0;i<DD;i++)
{sum1+= Math.sin(x[i])*Math.sin(x[i]);}

double sum2=0.0;
for(int i=0;i<DD;i++)
{sum2+= x[i]*x[i];}

double sum3=0.0;
for(int i=0;i<DD;i++)
{sum3+= Math.sin(Math.sqrt(Math.abs(x[i])))*Math.sin(Math.sqrt(Math.abs(x[i])));}


return (sum1-Math.exp(-sum2))*Math.exp(-sum3);

}

}


class f728 extends f_xj 
{//Raydan 1 
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;
double sum=0 ;
for(int i=0;i<DD;i++)
{sum+=(((double)i+1)/10.0)*(Math.exp(x[i])-x[i]);}
return sum;
}
}


class f729 extends f_xj 
{//Raydan 2 
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;
double sum=0.0; 
for(int i=0;i<DD;i++)
{sum+=(Math.exp(x[i])-x[i]);}
return sum;
}
}

class f730 extends f_xj 
{//Diagonal 1
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;
double sum=0.0; 
for(int i=0;i<DD;i++)
{sum+=(Math.exp(x[i])-((double)i+1)*x[i]);}
return sum;
}
}


class f731 extends f_xj 
{//Diagonal 2
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;
double sum=0.0; 
for(int i=0;i<DD;i++)
{sum+=(Math.exp(x[i])-(1/(double)i)*x[i]);}
return sum;
}
}


class f732 extends f_xj 
{//Diagonal 3
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;
double sum=0.0; 
for(int i=0;i<DD;i++)
{sum+=(Math.exp(x[i])-(double)(i+1)*Math.sin(x[i]));}
return sum;
}
}


class f733 extends f_xj 
{//Diagonal 3
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;
double sum=0.0; 
for(int i=0;i<DD;i++)
{sum+=(Math.exp(x[i])-(double)(i+1)*Math.sin(x[i]));}
return sum;
}
}

class f734 extends f_xj 
{//Hager
public double func(double x[]) 
{
int DD=x.length;
double m=5.0;
double beta=15.0;
double sum=0.0; 
for(int i=0;i<DD;i++)
{sum+=(Math.exp(x[i])-Math.sqrt((double)(i+1))*(x[i]));}
return sum;
}
}


class f735 extends f_xj 
{//Diagonal4
public double func(double x[]) 
{
int DD=x.length;
 
double sum=0.0; 
for(int i=0;i<DD/2;i++)
{sum+=x[2*i]*x[2*i] + 100.0*x[2*i+1]*x[2*i+1]     ;}
return 0.5*sum;
}
}


class f736 extends f_xj 
{//Diagonal5
public double func(double x[]) 
{
int DD=x.length;
 
double sum=0.0; 
for(int i=0;i<DD/2;i++)
{sum+= Math.log(Math.exp(x[i])+Math.exp(-x[i]));}
return sum;
}
}

class f737 extends f_xj 
{//Dixon_price
public double func(double x[]) 
{
int DD=x.length;
 
double sum=0.0; 
for(int i=1;i<DD;i++)
{sum+= (i+1)*(2.0*x[i]*x[i]-x[i-1])*(2.0*x[i]*x[i]-x[i-1]);}
return sum+(x[0]-1)*(x[0]-1);
}
}




class f738 extends f_xj 
{//Dropwave
public double func(double x[]) 
{
int DD=x.length;
 
double sum=0.0; 
for(int i=0;i<DD;i++)
{sum+=x[i]*x[i];}

return  -(1.0+Math.cos(12.0*Math.sqrt(sum)))/(0.5*sum+2.0);
}
}



//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////// CONSTRAINED OPTIMIZATION ////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////





// Minimize f(x)=(x[0]-6.0)*(x[0]-6.0)+(x[1]-7.0)*(x[1]-7.0)
//constrains
// g1(x)=-3*x[0]-2*x[1]+6.0<=0.0
// g2(x)=-x[0]-x[1]-3.0<=0.0
// g3(x)=x[0]+x[1]-7.0<=0.0
// g4(x)=0.66*x[0]-x[1]-1.333<=0.0
class f63 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=8.0;
return (x[0]-6.0)*(x[0]-6.0)+(x[1]-7.0)*(x[1]-7.0)+mu*(G1(x)+G2(x)+G3(x)+G4(x));
}

double G1(double x[])
{
return Math.pow(Math.max(0,-3*x[0]-2*x[1]+6.0),2.0);	
}
double G2(double x[])
{
return Math.pow(Math.max(0,-x[0]-x[1]-3.0),2.0);	
}
double G3(double x[])
{
return Math.pow(Math.max(0,x[0]+x[1]-7.0),2.0);	
}
double G4(double x[])
{
return Math.pow(Math.max(0,0.66*x[0]-x[1]-1.333),2.0);	
}
}
// Water cycle makalesinden al�nd�

// Minimize ((x[0]-10.0)*(x[0]-10.0))+(5.0*(x[1]-12.0)*(x[1]-12.0))+(x[2]*x[2]*x[2]*x[2])+(3.0*(x[3]-11.0)*(x[3]-11.0))+(10.0*(x[4]*x[4]*x[4]*x[4]*x[4]*x[4]))+(7.0*x[5]*x[5])+(x[6]*x[6]*x[6]*x[6])-(4.0*x[5]*x[6])-10*x[5]-8.0*x[6];
// constrains
// g1(x)=127.0-2.0*x[0]*x[0]-3.0*x[1]*x[1]*x[1]*x[1]-x[2]-4.0*x[3]*x[3]-5.0*x[4]>=0.0
// g2(x)=282.0-7.0*x[0]-3.0*x[1]-10.0*x[2]*x[2]-x[3]+x[4]>=0.0
// g3(x)=196.0-23.0*x[0]-x[1]*x[1]-6.0*x[5]*x[5]+8.0*x[6]>=0.0
// g4(x)=-4.0*x[0]*x[0]-x[1]*x[1]+3.0*x[0]*x[1]-2.0*x[2]*x[2]-5.0*x[5]+11.0*x[6]>=0.0

class f64 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=0.25;
return ((x[0]-10.0)*(x[0]-10.0))+(5.0*(x[1]-12.0)*(x[1]-12.0))+(x[2]*x[2]*x[2]*x[2])+(3.0*(x[3]-11.0)*(x[3]-11.0))+(10.0*(x[4]*x[4]*x[4]*x[4]*x[4]*x[4]))+(7.0*x[5]*x[5])+(x[6]*x[6]*x[6]*x[6])-(4.0*x[5]*x[6])-10*x[5]-8.0*x[6]+mu*(G1(x)+G2(x)+G3(x)+G4(x));
}

double G1(double x[])
{
return Math.pow(Math.min(0.0,127.0-2.0*x[0]*x[0]-3.0*x[1]*x[1]*x[1]*x[1]-x[2]-4.0*x[3]*x[3]-5.0*x[4]),2.0);	
}
double G2(double x[])
{
return Math.pow(Math.min(0.0,282.0-7.0*x[0]-3.0*x[1]-10.0*x[2]*x[2]-x[3]+x[4]),2.0);	
}
double G3(double x[])
{
return Math.pow(Math.min(0.0,196.0-23.0*x[0]-x[1]*x[1]-6.0*x[5]*x[5]+8.0*x[6]),2.0);	
}
double G4(double x[])
{
return Math.pow(Math.min(0.0,-4.0*x[0]*x[0]-x[1]*x[1]+3.0*x[0]*x[1]-2.0*x[2]*x[2]-5.0*x[5]+11.0*x[6]),2.0);	
}
}


// minimize 5.3578547*x[2]*x[2]*x[2]+0.8356891*x[0]*x[4]+37.203239*x[0]+40729.141
// constraints
// g1(x)=85.334407+0.0056858*x[1]*x[4]+0.0006262*x[0]*x[3]-0.0022053*x[2]*x[4]-92.0<=0.0
// g2(x)=-85.334407-0.0056858*x[1]*x[4]-0.0006262*x[0]*x[3]-0.0022053*x[2]*x[4]<=0.0
// g3(x)=80.51249+0.0071317*x[1]*x[4]+0.0029955*x[0]*x[1]+0.0021813*x[2]*x[2]-110.0<=0.0
// g4(x)=-80.51249-0.0071317*x[1]*x[4]-0.0029955*x[0]*x[1]-0.0021813*x[2]*x[2]+90.0<=0.0
// g5(x)=9.300961+0.0047026*x[2]*x[4]+0.0012547*x[0]*x[2]+0.0019085*x[2]*x[3]-25.0<=0.0
// g6(x)=-9.300961-0.0047026*x[2]*x[4]-0.0012547*x[0]*x[2]-0.0019085*x[2]*x[3]+20.0<=0.0
// 78<x[0]<102, 33<x[1]<45, 27<x[i]<45 i=2,3,4
class f65 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1953;
return (5.3578547*x[2]*x[2])+(0.8356891*x[0]*x[4])+(37.203239*x[0])-(40729.141)+(mu*(G1(x)+G2(x)+G3(x)+G4(x)+G5(x)+G6(x)));
}

double G1(double x[])
{
return Math.pow(Math.max(0.0,85.334407+0.0056858*x[1]*x[4]+0.0006262*x[0]*x[3]-0.0022053*x[2]*x[4]-92.0),2.0);	
}
double G2(double x[])
{
return Math.pow(Math.max(0.0,-85.334407-0.0056858*x[1]*x[4]-0.0006262*x[0]*x[3]+0.0022053*x[2]*x[4]),2.0);	
}
double G3(double x[])
{
return Math.pow(Math.max(0.0,80.51249+0.0071317*x[1]*x[3]+0.0029955*x[0]*x[1]+0.0021813*x[2]*x[2]-110.0),2.0);	
}
double G4(double x[])
{
return Math.pow(Math.max(0.0,-80.51249-0.0071317*x[1]*x[3]-0.0029955*x[0]*x[1]-0.0021813*x[2]*x[2]+90.0),2.0);	
}
double G5(double x[])
{
return Math.pow(Math.max(0.0,9.300961+0.0047026*x[2]*x[4]+0.0012547*x[0]*x[2]+0.0019085*x[2]*x[3]-25.0),2.0);	
}
double G6(double x[])
{
return Math.pow(Math.max(0.0,-9.300961-0.0047026*x[2]*x[4]-0.0012547*x[0]*x[2]-0.0019085*x[2]*x[3]+20.0),2.0);	
}
}

class f66 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1.1;
double s1=1.0;
int n=x.length;
for(int i=0;i<n;i++)
{s1*=x[i];}
s1=-Math.pow(Math.sqrt((double)n),(double)n)*s1;
return s1+(mu*G1(x));
}

double G1(double x[])
{
double c1=0.0;
int n=x.length;
for(int i=0;i<n;i++)
{c1+=(x[i]*x[i]);}
c1=c1-1;

return Math.abs(c1)-1e-4;
}
}

class f67 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1.2;
double s1=((3.0*x[0])+(1e-6*x[0]*x[0]*x[0])+(2.0*x[1])+((2e-6/3.0)*x[1]*x[1]*x[1]))+mu*(G1(x)+G2(x)+H1(x)+H2(x)+H3(x));
return s1;
}

double G1(double x[])
{
return  Math.pow(Math.max(0.0,x[2]-x[3]-0.55),2.0);	
}

double G2(double x[])
{
return Math.pow(Math.max(0.0,x[3]-x[2]-0.55),2.0);		
}

double H1(double x[])
{
return Math.abs(1000.0*(Math.sin(-x[2]-0.25)+Math.sin(-x[3]-0.25))+894.8-x[0])-1e-4;	
}

double H2(double x[])
{
return Math.abs(1000.0*(Math.sin(x[2]-0.25)+Math.sin(x[2]-x[3]-0.25))+894.8-x[1])-1e-4;	
}

double H3(double x[])
{
return Math.abs(1000.0*(Math.sin(x[3]-0.25)+Math.sin(x[3]-x[2]-0.25))+1294.8)-1e-4;	
}
}

class f68 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=0.007;
return ((x[0]-10.0)*(x[0]-10.0)*(x[0]-10.0))+((x[1]-20.0)*(x[1]-20.0)*(x[1]-20.0))+(mu*(G1(x)+G2(x)));
}

double G1(double x[])
{
return Math.pow(Math.max(0.0,(x[0]-5.0)*(x[0]-5.0)+(x[1]-5.0)*(x[1]-5.0)+100.0),2.0);
}
double G2(double x[])
{
return Math.pow(Math.max(0.0,(x[0]-5.0)*(x[0]-5.0)+(x[1]-5.0)*(x[1]-5.0)-82.81),2.0);
}
}

class f69 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1.0;
double s1=x[0]*x[0]+(x[1]-1.0)*(x[1]-1.0)+mu*(H1(x));
return s1;
}

double H1(double x[])
{
return Math.abs(x[1]-x[0]*x[0])-1e-4;
}
}

class f70 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=0.012;
double s1=Math.exp(x[0]*x[1]*x[2]*x[3]*x[4])+mu*(H1(x)+H2(x)+H3(x));
return s1;
}

double H1(double x[])
{
  int n=x.length;
  double d=0.0;
  for(int i=0;i<n;i++)
  {d+=x[i]*x[i];}
  return Math.abs(d-10.0)-1e-4; 	
	
}

double H2(double x[])
{
return  Math.abs(x[1]*x[2]-5.0*x[3]*x[4])-1e-4; 	
}

double H3(double x[])
{
return Math.abs(x[0]*x[0]*x[0]+x[1]*x[1]*x[1]+1.0)-1e-4;	
}

}

class f71 extends f_xj   //minr blsdt 1       
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=180.0;
double s1=(x[0]-2.0)*(x[0]-2.0)+(x[1]-1.0)*(x[1]-1.0)+(mu*(H1(x)+H2(x)));
return s1;
}

double H1(double x[])
{return Math.abs(x[0]-2.0*x[1]+1.0)-1e-4;}

double H2(double x[])
{return  Math.pow(Math.min(0.0,(-x[0]*x[0]/4.0)-x[1]*x[1]+1.0),2.0);}
}

class f72 extends f_xj   //minr blsdt 3       
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=10000.0;
double s1=(x[0]*x[0]+x[1]-11.0)*(x[0]*x[0]+x[1]-11.0)+(x[0]+x[1]*x[1]-7.0)*(x[0]+x[1]*x[1]-7.0)+(mu*(H1(x)+H2(x)));
return s1;
}

double H1(double x[])
{return Math.pow(Math.min(0.0,4.84-((x[0]-0.05)*(x[0]-0.05))-((x[1]-2.5)*(x[1]-2.5))),2.0);}

double H2(double x[])
{return  Math.pow(Math.min(0.0,x[0]*x[0]+(x[1]-2.5)*(x[1]-2.5)-4.84),2.0);}
}


// Three bar truss design problem
class f73 extends f_xj         
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=10000000.0;
double s1=((2.0*Math.sqrt(2.0)*x[0]+x[1])*100)+mu*(H1(x)+H2(x)+H3(x));
return s1;
}

double H1(double x[])
{return Math.pow(Math.max(0.0, (((Math.sqrt(2.0)*x[0]+x[1])/(Math.sqrt(2)*x[0]*x[0]+2.0*x[0]*x[1]))*2.0)-2.0  ),2.0);}

double H2(double x[])
{return  Math.pow(Math.max(0.0,    2.0*(x[1]/(Math.sqrt(2)*x[0]*x[0]+2.0*x[0]))-2.0),2.0);}

double H3(double x[])
{return  Math.pow(Math.max(0.0,2.0*(1.0/(Math.sqrt(2.0)*x[1]+x[0]))-2.0),2.0);}
}

// Presure vessel design problem !!!error
class f74 extends f_xj         
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1.0;
double s1=(0.6224*x[0]*x[2]*x[3])+(1.7781*x[1]*x[2]*x[2])+(3.1661*x[0]*x[0]*x[3])+(19.84*x[0]*x[0]*x[2])+(mu*(H1(x)+H2(x)+H3(x)+H4(x)));
return s1;
}

double H1(double x[])
{return Math.pow(Math.min(0.0, -x[0]+0.0193*x[2]),2.0);}

double H2(double x[])
{return  Math.pow(Math.min(0.0, -x[1]+0.00954*x[2]),2.0);}

double H3(double x[])
{return  Math.pow(Math.min(0.0,-3.1415*x[2]*x[2]*x[3]-(1.333)*3.1415*x[2]*x[2]*x[2]+1296000),2.0);}

double H4(double x[])
{return  Math.pow(Math.min(0.0,x[3]-240.0),2.0);}
}


//Tension/compression spring design problem
class f75 extends f_xj         
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=0.3;
double s1=((x[2]+2.0)*x[1]*x[0]*x[0])+(mu*(H1(x)+H2(x)+H3(x)+H4(x)));
return s1;
}

double H1(double x[])
{return Math.pow(Math.max(0.0,         1.0-((x[1]*x[1]*x[1]*x[2])/(71785.0*x[0]*x[0]*x[0]*x[0]))                  ),2.0);}

double H2(double x[])
{return  Math.pow(Math.max(0.0,        (((4.0*x[1]*x[1])-(x[0]*x[1]))/(12566.0*(x[1]*x[0]*x[0]*x[0]-x[0]*x[0]*x[0]*x[0])))+(1.0/(5108.0*x[0]*x[0]))-1.0              ),2.0);}

double H3(double x[])
{return  Math.pow(Math.max(0.0,        1.0-((140.45*x[0])/(x[1]*x[1]*x[2]))        ),2.0);}

double H4(double x[])
{return  Math.pow(Math.max(0.0,     ((x[0]+x[1])/1.5)-1.0        ),2.0);}
}


// Welded beam design

class f76 extends f_xj         
{
	
double P=6000.0;
double L=14.0;
double E=30000000.0;	
double G=12000000.0;
double tomax=13600.0;
double sigmax=30000.0;
double deltamax=0.25;

double sigma(double x[])
{return (6.0*P*L)/(x[3]*x[2]*x[2]);}

double delta(double x[])
{return (4.0*P*L*L*L)/(E*x[2]*x[2]*x[2]*x[3]);}

double Pc(double x[])
{return (4.013*E/(6.0*L*L))*x[2]*x[3]*x[3]*x[3]*(1-0.25*x[2]*Math.sqrt(E/G)/L);}
	
double J(double x[])
{return   2.0/Math.sqrt(2)*x[0]*x[1]*(x[1]*x[1]/12.0+0.25*(x[0]+x[2])*(x[0]+x[2]));                    }
	
double R(double x[])
{return	Math.sqrt(0.25*(x[1]*x[1]+(x[0]+x[2])*(x[0]+x[2])));}

double M(double x[])
{return P*(L+x[1]/2.0);}

double to1(double x[])
{return P/(Math.sqrt(2)*x[0]*x[1]);}

double to2(double x[])
{return M(x)*R(x)/J(x);}

double toend(double x[])
{return Math.sqrt(to1(x)*to1(x)+(2.0*to1(x)*to2(x)*x[1]/(2.0*R(x)))+to2(x)*to2(x));}
	
	
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=0.0000000015;
double s1=(1.10471*x[0]*x[0]*x[1])+(0.04811*x[2]*x[3]*(14.0+x[1]))+(mu*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+H6(x)+H7(x)));
return s1;
}

double H1(double x[])
{return Math.pow(Math.max(0.0,         toend(x)-tomax                 ),2.0);}

double H2(double x[])
{return  Math.pow(Math.max(0.0,         sigma(x)-sigmax           ),2.0);}

double H3(double x[])
{return  Math.pow(Math.max(0.0,        x[0]-x[3]        ),2.0);}

double H4(double x[])
{return  Math.pow(Math.max(0.0,       0.10471*x[0]*x[0]+0.04811*x[2]*x[3]*(14.0+x[1])-5.0         ),2.0);}

double H5(double x[])
{return  Math.pow(Math.max(0.0,      0.125-x[0]         ),2.0);}

double H6(double x[])	
{return  Math.pow(Math.max(0.0,       delta(x)-deltamax         ),2.0);}

double H7(double x[])
{return  Math.pow(Math.max(0.0,       P-Pc(x)         ),2.0);}

}


// speed reducer design problem
class f77 extends f_xj         
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=18200000.7;
double s1=0.7854*x[0]*x[1]*x[1]*(3.3333*x[2]*x[2]+14.9334*x[2]-43.0934)-(1.508*x[0]*(x[5]*x[5]+x[6]*x[6]))+(7.4777*(x[5]*x[5]*x[5]+x[6]*x[6]*x[6]))+(0.7854*(x[3]*x[5]*x[5]+x[4]*x[6]*x[6]))+(mu*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+H6(x)+H7(x)+H8(x)+H9(x)+H10(x)+H11(x)));
return s1;
}

double H1(double x[])
{return Math.pow(Math.max(0.0,         (27.0/(x[0]*x[1]*x[1]*x[2]))-1.0                 ),2.0);}

double H2(double x[])
{return  Math.pow(Math.max(0.0,       (397.5/(x[0]*x[1]*x[1]*x[2]*x[2]))-1.0             ),2.0);}

double H3(double x[])
{return  Math.pow(Math.max(0.0,      ((1.93*x[3]*x[3]*x[3])/(x[1]*x[5]*x[5]*x[5]*x[5]*x[2]))-1.0          ),2.0);}

double H4(double x[])
{return  Math.pow(Math.max(0.0,     ((1.93*x[4]*x[4]*x[4])/(x[1]*x[6]*x[6]*x[6]*x[6]*x[2]))-1.0        ),2.0);}

double H5(double x[])
{return  Math.pow(Math.max(0.0,     (Math.sqrt((745.0*(x[3]/(x[1]*x[2])))*(745.0*(x[3]/(x[1]*x[2])))+16.9e6)/(110.0*x[5]*x[5]*x[5]))-1.0                                    ),2.0);}

double H6(double x[])
{return  Math.pow(Math.max(0.0,    (Math.sqrt((745.0*(x[4]/(x[1]*x[2])))*(745.0*(x[3]/(x[1]*x[2])))+157.5e6)/(85.0*x[6]*x[6]*x[6]))-1.0     ),2.0);}

double H7(double x[])
{return  Math.pow(Math.max(0.0,     (x[1]*x[2]/40.0)-1.0        ),2.0);}

double H8(double x[])
{return  Math.pow(Math.max(0.0,     (5.0*x[1]/x[0])-1.0        ),2.0);}

double H9(double x[])
{return  Math.pow(Math.max(0.0,     (x[0]/(12.0*x[1]))-1.0      ),2.0);}

double H10(double x[])
{return  Math.pow(Math.max(0.0,     ((1.5*x[5]+1.9)/x[3])-1.0        ),2.0);}

double H11(double x[])
{return  Math.pow(Math.max(0.0,     ((1.1*x[6]+1.9)/x[4])-1.0       ),2.0);}


}



class par_est2 extends f_xj
{
	
public double func(double x[])
{
double[] I1={4.84992,10.7714,16.0843,21.1287,26.5745,32.2935,37.7378,42.7127,48.5654,54.0119,59.3275,65.3104,70.2269,75.6784};
double[] V1={0.921044,0.875721,0.848175,0.819634,0.798022,0.756648,0.741955,0.723297,0.684891,0.660314,0.620907,0.600297,0.544075,0.497752};
double[] V_dummy1=new double[14];
double N=1.0;
//double Jmax=0.86;//I/cm2
double RHa=1.0;
double RHb=1.0;
double A=50.6;//cm2
double l=178.0e-4;//cm
//initialize
double Rm=0.0;
double T=343.15;//K
double PO2=1.0;//atm
double PH2=1.0;
double V_Ernst=0.0;
double CO2=0.0;
double V_act=0.0;
double ro_m=0.0;
double R_m=0.0;
double V_ohm=0.0;
double V_con=0.0;

for(int i=0;i<14;i++)
{
    
    
			
	   
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(  (I1[i]+(x[10]/x[9]))   )));
        ro_m=181.6*(1.0+(0.03*(   (I1[i]+(x[10]/x[9]))    /x[9]  ))+(0.062*(T/303.0)*(T/303.0)*Math.pow((     (I1[i]+(x[10]/x[9]))   /   x[9]),2.5)))/((x[4]-0.634-3.0*(   (I1[i]+(x[10]/x[9]))  /    x[9]))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*x[7]/x[9];
	    V_ohm=(I1[i]+(x[10]/x[9]))*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((( (I1[i]+(x[10]/x[9]))  /  x[9]))/x[8]));
	    V_dummy1[i]=N*(V_Ernst-V_act-V_ohm-V_con);
    
	
	
	
	
}

double val1=0.0;	
for(int i=0;i<14;i++)
{val1+=(V1[i]-V_dummy1[i])*(V1[i]-V_dummy1[i]);}

return val1;	
	
}	


double psat(double T)
{
return	Math.pow(10.0,((2.95e-2*(T-273.15))-((9.18e-5)*(T-273.15)*(T-273.15))+((1.44e-7)*(T-273.15)*(T-273.15)*(T-273.15))-2.18));	
}	
	
double bartoatm(double barr)
{return barr*0.986923267;}	
	
	
	
}


class par_est extends f_xj
{
	
public double func(double x[])
{
double[] I1={0.227213,1.3085,2.6534,3.99747,5.36203,6.70621,8.05038,10.7587,13.4467,16.1351,17.4995,18.8436,20.208,21.5522,22.9172};
double[] V1={23.5485,21.4567,20.3221,19.935,19.4284,18.9516,18.4748,17.8501,17.2553,16.212,15.8548,15.4976,15.1405,14.6338,13.6786};
double[] I2={0.224307,1.30506,2.6509,3.99674,5.36297,6.70881,8.05465,10.7463,13.4584,16.1705,17.5163,18.8825,20.2284,21.5742,22.9201};
double[] V2={21.5522,19.7015,18.7463,18.0,17.5522,17.1642,16.6567,15.9104,15.1642,14.4478,14.0299,13.5522,12.6567,10.8955,8.89552};
double[] I3={0.285837,1.32988,2.66286,4.05778,5.39127,6.76593,8.079,10.7874,13.4959,16.1836,17.5584,18.8716,20.2667,21.5792,22.9325};
double[] V3={23.235,21.0279,20.0851,19.4364,18.9054,18.4626,18.0199,17.2814,16.543,15.6869,15.3029,14.9484,14.4762,13.5923,12.5024};
double[] I4={0.248484,1.29844,2.65425,4.03034,5.36496,6.74076,8.07542,10.7858,13.4961,16.1653,17.5409,18.8553,20.2521,21.5878,22.9242};
double[] V4={22.6822,20.1581,19.2495,18.5463,18.1662,17.698,17.2885,16.4695,15.7092,14.9782,14.6862,14.0711,13.2212,12.0188,10.1705};


double[][] V_dummy=new double[4][15];
double[][] V_real=new double[4][15];
double[][] Ireal=new double[4][15];

for(int j=0;j<15;j++)
{V_real[0][j]=V1[j];}	
for(int j=0;j<15;j++)
{V_real[1][j]=V2[j];}	
for(int j=0;j<15;j++)
{V_real[2][j]=V3[j];}	
for(int j=0;j<15;j++)
{V_real[3][j]=V4[j];}

for(int j=0;j<15;j++)
{Ireal[0][j]=I1[j];}	
for(int j=0;j<15;j++)
{Ireal[1][j]=I2[j];}	
for(int j=0;j<15;j++)
{Ireal[2][j]=I3[j];}	
for(int j=0;j<15;j++)
{Ireal[3][j]=I4[j];}

double N=24.0;
double Jmax=0.86;//I/cm2
double RHa=1.0;
double RHb=1.0;
double A=27.0;//cm2
double l=127.0e-4;//cm


//initialize





double Rm=0.0;


double Pa_atm=0.0;
double Pb_atm=0.0;
double T=0.0;//K
double Pa=0.0;//bar
double Pb=0.0;//bar
double PO2=0.0;//atm
double PH2=0.0;
double V_Ernst=0.0;
double CO2=0.0;
double V_act=0.0;
double ro_m=0.0;
double R_m=0.0;
double V_ohm=0.0;
double V_con=0.0;

for(int i=0;i<4;i++)
{
    if(i==0)
    {
	 T=353.15;    
	 Pa=3.0;
	 Pb=5.0; 
	 Pa_atm=bartoatm(Pa);
	 Pb_atm=bartoatm(Pb);  
	 for(int j=0;j<15;j++)
     { 		
	    PO2=RHb*psat(T)*((1.0/(Math.exp((4.192*Ireal[i][j]/A)/(Math.pow(T,1.334)))*(RHb*psat(T)/Pb_atm)))-1.0);
		PH2=0.5*RHa*psat(T)*((1.0/(Math.exp((1.635*Ireal[i][j]/A)/(Math.pow(T,1.334)))*(RHa*psat(T)/Pa_atm)))-1.0);
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(Ireal[i][j])));
        ro_m=181.6*(1.0+(0.03*(Ireal[i][j]/A))+(0.062*(T/303.0)*(T/303.0)*Math.pow((Ireal[i][j]/A),2.5)))/((x[4]-0.634-3.0*(Ireal[i][j]/A))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*l/A;
	    V_ohm=Ireal[i][j]*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((Ireal[i][j]/A)/Jmax));
	    V_dummy[i][j]=N*(V_Ernst-V_act-V_ohm-V_con);
     }	    
	}
	if(i==1)
    {
	 T=343.15;    
	 Pa=1.0;
	 Pb=1.0; 
	 Pa_atm=bartoatm(Pa);
	 Pb_atm=bartoatm(Pb);  
	 for(int j=0;j<15;j++)
     { 		
	    PO2=RHb*psat(T)*((1.0/(Math.exp((4.192*Ireal[i][j]/A)/(Math.pow(T,1.334)))*(RHb*psat(T)/Pb_atm)))-1.0);
		PH2=0.5*RHa*psat(T)*((1.0/(Math.exp((1.635*Ireal[i][j]/A)/(Math.pow(T,1.334)))*(RHa*psat(T)/Pa_atm)))-1.0);
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(Ireal[i][j])));
        ro_m=181.6*(1.0+(0.03*(Ireal[i][j]/A))+(0.062*(T/303.0)*(T/303.0)*Math.pow((Ireal[i][j]/A),2.5)))/((x[4]-0.634-3.0*(Ireal[i][j]/A))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*l/A;
	    V_ohm=Ireal[i][j]*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((Ireal[i][j]/A)/Jmax));
	    V_dummy[i][j]=N*(V_Ernst-V_act-V_ohm-V_con);
     }	    
	}	
	if(i==2)
    {
	 T=343.15;    
	 Pa=2.5;
	 Pb=3.0; 
	 Pa_atm=bartoatm(Pa);
	 Pb_atm=bartoatm(Pb);  
	 for(int j=0;j<15;j++)
     { 		
	    PO2=RHb*psat(T)*((1.0/(Math.exp((4.192*Ireal[i][j]/A)/(Math.pow(T,1.334)))*(RHb*psat(T)/Pb_atm)))-1.0);
		PH2=0.5*RHa*psat(T)*((1.0/(Math.exp((1.635*Ireal[i][j]/A)/(Math.pow(T,1.334)))*(RHa*psat(T)/Pa_atm)))-1.0);
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(Ireal[i][j])));
        ro_m=181.6*(1.0+(0.03*(Ireal[i][j]/A))+(0.062*(T/303.0)*(T/303.0)*Math.pow((Ireal[i][j]/A),2.5)))/((x[4]-0.634-3.0*(Ireal[i][j]/A))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*l/A;
	    V_ohm=Ireal[i][j]*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((Ireal[i][j]/A)/Jmax));
	    V_dummy[i][j]=N*(V_Ernst-V_act-V_ohm-V_con);
     }	    
	}
	if(i==3)
    {
	 T=343.15;    
	 Pa=1.5;
	 Pb=1.5; 
	 Pa_atm=bartoatm(Pa);
	 Pb_atm=bartoatm(Pb);  
	 for(int j=0;j<15;j++)
     { 		
	    PO2=RHb*psat(T)*((1.0/(Math.exp((4.192*Ireal[i][j]/A)/(Math.pow(T,1.334)))*(RHb*psat(T)/Pb_atm)))-1.0);
		PH2=0.5*RHa*psat(T)*((1.0/(Math.exp((1.635*Ireal[i][j]/A)/(Math.pow(T,1.334)))*(RHa*psat(T)/Pa_atm)))-1.0);
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(Ireal[i][j])));
        ro_m=181.6*(1.0+(0.03*(Ireal[i][j]/A))+(0.062*(T/303.0)*(T/303.0)*Math.pow((Ireal[i][j]/A),2.5)))/((x[4]-0.634-3.0*(Ireal[i][j]/A))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*l/A;
	    V_ohm=Ireal[i][j]*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((Ireal[i][j]/A)/Jmax));
	    V_dummy[i][j]=N*(V_Ernst-V_act-V_ohm-V_con);
     }	    
	}
	
}

double val=0.0;	
for(int i=0;i<4;i++)
{
  for(int j=0;j<15;j++)
  {
  val+=(V_real[i][j]-V_dummy[i][j])*(V_real[i][j]-V_dummy[i][j]);   	  
  }	
}

return val;	
	
}	


double psat(double T)
{
return	Math.pow(10.0,((2.95e-2*(T-273.15))-((9.18e-5)*(T-273.15)*(T-273.15))+((1.44e-7)*(T-273.15)*(T-273.15)*(T-273.15))-2.18));	
}	
	
double bartoatm(double barr)
{return barr*0.986923267;}	
}

class par_est4 extends f_xj
{
	
public double func(double x[])
{
double[] I1={0.01,4.99101,10.009,15.0,19.964,25.036,30.027};
double[] V11={30.1304,24.8478,22.1087,20.25,19.2717,18.6848,17.1196};
double[] V_dummy1=new double[V11.length];
double N=32.0;
//double Jmax=0.86;//I/cm2
double RHa=1.0;
double RHb=1.0;
double A=50.6;//cm2
double l=178.0e-4;//cm
//initialize
double Rm=0.0;
double T=333.0;//K
double PO2=0.2095;//atm
double PH2=1.000;
double V_Ernst=0.0;
double CO2=0.0;
double V_act=0.0;
double ro_m=0.0;
double R_m=0.0;
double V_ohm=0.0;
double V_con=0.0;

for(int i=0;i<V11.length;i++)
{
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(  (I1[i]+(x[10]/x[9]))   )));
        ro_m=181.6*(1.0+(0.03*(   (I1[i]+(x[10]/x[9]))    /x[9]  ))+(0.062*(T/303.0)*(T/303.0)*Math.pow((     (I1[i]+(x[10]/x[9]))   /   x[9]),2.5)))/((x[4]-0.634-3.0*(   (I1[i]+(x[10]/x[9]))  /    x[9]))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*x[7]/x[9];
	    V_ohm=(I1[i]+(x[10]/x[9]))*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((( (I1[i]+(x[10]/x[9]))  /  x[9]))/x[8]));
	    V_dummy1[i]=N*(V_Ernst-V_act-V_ohm-V_con);
}

double val1=0.0;	
for(int i=0;i<V11.length;i++)
{val1+=(V11[i]-V_dummy1[i])*(V11[i]-V_dummy1[i]);}

return val1;	
	
}	


double psat(double T)
{return	Math.pow(10.0,((2.95e-2*(T-273.15))-((9.18e-5)*(T-273.15)*(T-273.15))+((1.44e-7)*(T-273.15)*(T-273.15)*(T-273.15))-2.18));}	
	
double bartoatm(double barr)
{return barr*0.986923267;}	
	
}


class par_est3 extends f_xj
{
	
public double func(double x[])
{
double[] I1={0.227213,1.3085,2.6534,3.99747,5.36203,6.70621,8.05038,10.7587,13.4467,16.1351,17.4995,18.8436,20.208,21.5522,22.9172};
double[] V1={23.5485,21.4567,20.3221,19.935,19.4284,18.9516,18.4748,17.8501,17.2553,16.212,15.8548,15.4976,15.1405,14.6338,13.6786};
double[] I2={0.224307,1.30506,2.6509,3.99674,5.36297,6.70881,8.05465,10.7463,13.4584,16.1705,17.5163,18.8825,20.2284,21.5742,22.9201};
double[] V2={21.5522,19.7015,18.7463,18.0,17.5522,17.1642,16.6567,15.9104,15.1642,14.4478,14.0299,13.5522,12.6567,10.8955,8.89552};
double[] I3={0.285837,1.32988,2.66286,4.05778,5.39127,6.76593,8.079,10.7874,13.4959,16.1836,17.5584,18.8716,20.2667,21.5792,22.9325};
double[] V3={23.235,21.0279,20.0851,19.4364,18.9054,18.4626,18.0199,17.2814,16.543,15.6869,15.3029,14.9484,14.4762,13.5923,12.5024};
double[] I4={0.248484,1.29844,2.65425,4.03034,5.36496,6.74076,8.07542,10.7858,13.4961,16.1653,17.5409,18.8553,20.2521,21.5878,22.9242};
double[] V4={22.6822,20.1581,19.2495,18.5463,18.1662,17.698,17.2885,16.4695,15.7092,14.9782,14.6862,14.0711,13.2212,12.0188,10.1705};


double[][] V_dummy=new double[4][15];
double[][] V_real=new double[4][15];
double[][] Ireal=new double[4][15];

for(int j=0;j<15;j++)
{V_real[0][j]=V1[j];}	
for(int j=0;j<15;j++)
{V_real[1][j]=V2[j];}	
for(int j=0;j<15;j++)
{V_real[2][j]=V3[j];}	
for(int j=0;j<15;j++)
{V_real[3][j]=V4[j];}

for(int j=0;j<15;j++)
{Ireal[0][j]=I1[j];}	
for(int j=0;j<15;j++)
{Ireal[1][j]=I2[j];}	
for(int j=0;j<15;j++)
{Ireal[2][j]=I3[j];}	
for(int j=0;j<15;j++)
{Ireal[3][j]=I4[j];}

double N=24.0;
//double Jmax=0.86;//I/cm2
double RHa=1.0;
double RHb=1.0;
//double A=27.0;//cm2
//double l=127.0e-4;//cm


//initialize





double Rm=0.0;


double Pa_atm=0.0;
double Pb_atm=0.0;
double T=0.0;//K
double Pa=0.0;//bar
double Pb=0.0;//bar
double PO2=0.0;//atm
double PH2=0.0;
double V_Ernst=0.0;
double CO2=0.0;
double V_act=0.0;
double ro_m=0.0;
double R_m=0.0;
double V_ohm=0.0;
double V_con=0.0;

for(int i=0;i<4;i++)
{
    if(i==0)
    {
	 T=353.15;    
	 Pa=3.0;
	 Pb=5.0; 
	 Pa_atm=bartoatm(Pa);
	 Pb_atm=bartoatm(Pb);  
	 for(int j=0;j<15;j++)
     { 		
	    PO2=RHb*psat(T)*((1.0/(Math.exp((4.192*Ireal[i][j]/x[9])/(Math.pow(T,1.334)))*(RHb*psat(T)/Pb_atm)))-1.0);
		PH2=0.5*RHa*psat(T)*((1.0/(Math.exp((1.635*Ireal[i][j]/x[9])/(Math.pow(T,1.334)))*(RHa*psat(T)/Pa_atm)))-1.0);
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(Ireal[i][j])));
        ro_m=181.6*(1.0+(0.03*(Ireal[i][j]/x[9]))+(0.062*(T/303.0)*(T/303.0)*Math.pow((Ireal[i][j]/x[9]),2.5)))/((x[4]-0.634-3.0*(Ireal[i][j]/x[9]))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*x[7]/x[9];
	    V_ohm=Ireal[i][j]*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((Ireal[i][j]/x[9])/x[8]));
	    V_dummy[i][j]=N*(V_Ernst-V_act-V_ohm-V_con);
     }	    
	}
	if(i==1)
    {
	 T=343.15;    
	 Pa=1.0;
	 Pb=1.0; 
	 Pa_atm=bartoatm(Pa);
	 Pb_atm=bartoatm(Pb);  
	 for(int j=0;j<15;j++)
     { 		
	    PO2=RHb*psat(T)*((1.0/(Math.exp((4.192*Ireal[i][j]/x[9])/(Math.pow(T,1.334)))*(RHb*psat(T)/Pb_atm)))-1.0);
		PH2=0.5*RHa*psat(T)*((1.0/(Math.exp((1.635*Ireal[i][j]/x[9])/(Math.pow(T,1.334)))*(RHa*psat(T)/Pa_atm)))-1.0);
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(Ireal[i][j])));
        ro_m=181.6*(1.0+(0.03*(Ireal[i][j]/x[9]))+(0.062*(T/303.0)*(T/303.0)*Math.pow((Ireal[i][j]/x[9]),2.5)))/((x[4]-0.634-3.0*(Ireal[i][j]/x[9]))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*x[7]/x[9];
	    V_ohm=Ireal[i][j]*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((Ireal[i][j]/x[9])/x[8]));
	    V_dummy[i][j]=N*(V_Ernst-V_act-V_ohm-V_con);
     }	    
	}	
	if(i==2)
    {
	 T=343.15;    
	 Pa=2.5;
	 Pb=3.0; 
	 Pa_atm=bartoatm(Pa);
	 Pb_atm=bartoatm(Pb);  
	 for(int j=0;j<15;j++)
     { 		
	    PO2=RHb*psat(T)*((1.0/(Math.exp((4.192*Ireal[i][j]/x[9])/(Math.pow(T,1.334)))*(RHb*psat(T)/Pb_atm)))-1.0);
		PH2=0.5*RHa*psat(T)*((1.0/(Math.exp((1.635*Ireal[i][j]/x[9])/(Math.pow(T,1.334)))*(RHa*psat(T)/Pa_atm)))-1.0);
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(Ireal[i][j])));
        ro_m=181.6*(1.0+(0.03*(Ireal[i][j]/x[9]))+(0.062*(T/303.0)*(T/303.0)*Math.pow((Ireal[i][j]/x[9]),2.5)))/((x[4]-0.634-3.0*(Ireal[i][j]/x[9]))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*x[7]/x[9];
	    V_ohm=Ireal[i][j]*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((Ireal[i][j]/x[9])/x[8]));
	    V_dummy[i][j]=N*(V_Ernst-V_act-V_ohm-V_con);
     }	    
	}
	if(i==3)
    {
	 T=343.15;    
	 Pa=1.5;
	 Pb=1.5; 
	 Pa_atm=bartoatm(Pa);
	 Pb_atm=bartoatm(Pb);  
	 for(int j=0;j<15;j++)
     { 		
	    PO2=RHb*psat(T)*((1.0/(Math.exp((4.192*Ireal[i][j]/x[9])/(Math.pow(T,1.334)))*(RHb*psat(T)/Pb_atm)))-1.0);
		PH2=0.5*RHa*psat(T)*((1.0/(Math.exp((1.635*Ireal[i][j]/x[9])/(Math.pow(T,1.334)))*(RHa*psat(T)/Pa_atm)))-1.0);
        V_Ernst=1.229-(0.85e-3*(T-298.15))+(4.3085e-5*T*(Math.log(PH2)+0.5*Math.log(PO2)));
        CO2=PO2/(5.086e6*Math.exp(-498.0/T));
        V_act=-(x[0]+(x[1]*T)+(x[2]*T*Math.log(CO2))+(x[3]*T*Math.log(Ireal[i][j])));
        ro_m=181.6*(1.0+(0.03*(Ireal[i][j]/x[9]))+(0.062*(T/303.0)*(T/303.0)*Math.pow((Ireal[i][j]/x[9]),2.5)))/((x[4]-0.634-3.0*(Ireal[i][j]/x[9]))*Math.exp(4.18*((T-303.0)/T)));
	    R_m=ro_m*x[7]/x[9];
	    V_ohm=Ireal[i][j]*(R_m+x[5]);
	    V_con=-x[6]*Math.log(1.0-((Ireal[i][j]/x[9])/x[8]));
	    V_dummy[i][j]=N*(V_Ernst-V_act-V_ohm-V_con);
     }	    
	}
	
}

double val=0.0;	
for(int i=0;i<4;i++)
{
  for(int j=0;j<15;j++)
  {
  val+=(V_real[i][j]-V_dummy[i][j])*(V_real[i][j]-V_dummy[i][j]);   	  
  }	
}

return val;	
	
}	


double psat(double T)
{
return	Math.pow(10.0,((2.95e-2*(T-273.15))-((9.18e-5)*(T-273.15)*(T-273.15))+((1.44e-7)*(T-273.15)*(T-273.15)*(T-273.15))-2.18));	
}	
	
double bartoatm(double barr)
{return barr*0.986923267;}	
}


class solar2 extends f_xj
{
double func(double x[])
{
// double  diode	
double[] Vt={-0.2057,-0.1291,-0.0588,0.0057,0.0646,0.1185,0.1678,0.2132,0.2545,0.2924,0.3269,0.3585,0.3873,0.4137,0.4373,0.459,0.4784,0.496,0.5119,0.5265,0.5398,0.5521,0.5633,0.5736,0.5833,0.59};
double[] It={0.764,0.762,0.7605,0.7605,0.76,0.759,0.757,0.757,0.7555,0.754,0.7505,0.7465,0.7385,0.728,0.7065,0.6755,0.632,0.573,0.499,0.413,0.3165,0.212,0.1035,-0.01,-0.123,-0.21};
//Rs    x[0]
//Rsh   x[1]
//IPh   x[2]	
//Isd1  x[3]	
//n1    x[4]
//Isd2  x[5]
//n2    x[6]
double q=1.602176565e-19;// electronic charge
double kb=1.3806505e-23;//Boltzmann
double T=273.15+33.0;

int m=Vt.length;
double sum=0.0;


for(int i=0;i<m;i++)
{sum+=(It[i]-x[2]+(x[3]*(Math.exp(q*(Vt[i]+x[0]*It[i])/(x[4]*kb*T))-1.0))+(x[5]*(Math.exp(q*(Vt[i]+x[0]*It[i])/(x[6]*kb*T))-1.0))+((Vt[i]+x[0]*It[i])/(x[1])))*(It[i]-x[2]+(x[3]*(Math.exp(q*(Vt[i]+x[0]*It[i])/(x[4]*kb*T))-1.0))+(x[5]*(Math.exp(q*(Vt[i]+x[0]*It[i])/(x[6]*kb*T))-1.0))+((Vt[i]+x[0]*It[i])/(x[1]))) ;}
	
return Math.sqrt(sum/(double)m);	
}	
}

class solar1 extends f_xj// Himmelblau f(x)=0.0  @x=(3.0,2.0),(-2.8051,3.1313),(-3.7793,-3.2831),(3.5844,-1.8481)   -6.0<=x[i]<=6.0 i=0,1
{
double func(double x[])
{
// single diode	
double[] Vt={-0.2057,-0.1291,-0.0588,0.0057,0.0646,0.1185,0.1678,0.2132,0.2545,0.2924,0.3269,0.3585,0.3873,0.4137,0.4373,0.459,0.4784,0.496,0.5119,0.5265,0.5398,0.5521,0.5633,0.5736,0.5833,0.59};
double[] It={0.764,0.762,0.7605,0.7605,0.76,0.759,0.757,0.757,0.7555,0.754,0.7505,0.7465,0.7385,0.728,0.7065,0.6755,0.632,0.573,0.499,0.413,0.3165,0.212,0.1035,-0.01,-0.123,-0.21};
//Rs   x[0]
//Rsh  x[1]
//IPh  x[2]	
//Isd  x[3]	
//n    x[4]
double q=1.602176565e-19;// electronic charge
double kb=1.3806505e-23;//Boltzmann
double T=273.15+33.0;

int m=Vt.length;
double sum=0.0;


for(int i=0;i<m;i++)
{sum+=(It[i]-x[2]+(x[3]*(Math.exp(q*(Vt[i]+x[0]*It[i])/(x[4]*kb*T))-1.0))+((Vt[i]+x[0]*It[i])/(x[1])))*(It[i]-x[2]+(x[3]*(Math.exp(q*(Vt[i]+x[0]*It[i])/(x[4]*kb*T))-1.0))+((Vt[i]+x[0]*It[i])/(x[1])));}
	
return Math.sqrt(sum/(double)m);	
}	
}


class pv extends f_xj// Himmelblau f(x)=0.0  @x=(3.0,2.0),(-2.8051,3.1313),(-3.7793,-3.2831),(3.5844,-1.8481)   -6.0<=x[i]<=6.0 i=0,1
{
double func(double x[])
{
// double  diode	
double[] Vt={0.1248,1.8093,3.3511,4.7622,6.0538,7.2364,8.3189,9.3097,10.2163,11.0449,11.8018,12.4929,13.1231,13.6983,14.2221,14.6995,15.1346,15.5311,15.8929,16.2229,16.5241,16.7987,17.0499,17.2793,17.4885};
double[] It={1.0315,1.0300,1.0260,1.0220,1.0180,1.0155,1.0140,1.0100,1.0035,0.9880,0.9630,0.9255,0.8725,0.8075,0.7265,0.6345,0.5345,0.4275,0.3185,0.2085,0.1010,-0.0080,-0.1110,-0.2090,-0.3030 };
//Rs    x[0]
//Rsh   x[1]
//IPh   x[2]	
//Isd1  x[3]	
//n1    x[4]

double q=1.602176565e-19;// electronic charge
double kb=1.3806505e-23;//Boltzmann
double T=273.15+45.0;
double Np=1.0;
double Ns=36.0;
double Vtt=kb*T/q;

int m=Vt.length;
double sum=0.0;


for(int i=0;i<m;i++)
{sum+=(It[i]-x[2]+(x[3]*(Math.exp((Vt[i]+It[i]*x[0])/(x[4]*Vtt*Ns))-1.0))+(((Vt[i]+It[i]*x[0])/(x[1]))))*(It[i]-x[2]+(x[3]*(Math.exp((Vt[i]+It[i]*x[0])/(x[4]*Vtt*Ns))-1.0))+(((Vt[i]+It[i]*x[0])/(x[1]))))    ;}
	
return Math.sqrt(sum/(double)m);	
}	
}

class f2001 extends f_xj //optimal chiller case 1 coelho
{
	
double[] RT={1280.0,1280.0,1280.0,1280.0,1250.0,1250.0};
double CL=5334.0;

public double func(double x[]) 
{
double P[]=new double[6]; 	
double a[]={399.345,287.116,-120.505,-19.121,-95.029,191.750};
double b[]={-122.12,80.04,1525.99,898.76,1202.39,224.86};	
double c[]={770.46,700.48,-502.14,-98.15,-352.16,524.04};


double sum=0.0;
for(int i=0;i<6;i++)
{P[i]=a[i]+b[i]*x[i]+c[i]*x[i]*x[i];}
for(int i=0;i<6;i++)
{sum+=P[i];}
return sum+5.0*H(x);
}

double H(double x[])
{
double sum1=0.0;	
for(int i=0;i<6;i++)
{sum1+=x[i]*RT[i];}
return Math.abs(sum1-CL)-1e-8;
}
}


class f2002 extends f_xj //optimal chiller case 2 coelho
{
double RT=800.0;
double CL=960.0;

public double func(double x[]) 
{
double P[]=new double[3]; 	
double a[]={100.95,66.598,130.09};
double b[]={818.61,606.34,304.5};	
double c[]={-973.43,-380.58,14.377};
double d[]={788.55,275.95,99.8};


double sum=0.0;
for(int i=0;i<3;i++)
{P[i]=a[i]+b[i]*x[i]+c[i]*x[i]*x[i]+d[i]*x[i]*x[i]*x[i];}
for(int i=0;i<3;i++)
{sum+=P[i];}
return sum+5.0*H(x);
}

double H(double x[])
{
double sum1=0.0;	
for(int i=0;i<3;i++)
{sum1+=x[i]*RT;}
return Math.abs(sum1-CL)-1e-8;
}
}

class f2003 extends f_xj //optimal chiller case 3 genetic chang 
{
double[] RT={450.0,450,1000.0,1000.0};
double CL=1450.0;

public double func(double x[]) 
{
double P[]=new double[4]; 	
double a[]={104.09,-67.15,384.71,541.63};
double b[]={166.57,1177.79,-779.13,413.48};	
double c[]={-430.13,-2174.53,1151.42,-3626.50};
double d[]={512.53,1456.53,-63.20,4021.41};


double sum=0.0;
for(int i=0;i<4;i++)
{P[i]=a[i]+b[i]*x[i]+c[i]*x[i]*x[i]+d[i]*x[i]*x[i]*x[i];}
for(int i=0;i<4;i++)
{sum+=P[i];}
return sum+5.0*H(x);
}

double H(double x[])
{
double sum1=0.0;	
for(int i=0;i<4;i++)
{sum1+=x[i]*RT[i];}
return Math.abs(sum1-CL)-1e-8;
}
}


class dam2 extends f_xj
{
  
 

double func(double x[])
{
// x[0]  x[1]  x[2]  x[3]  x[4]  x[5]  x[6]  x[7]  x[8]  x[9]  x[10]  x[11]  x[12]  x[13]  x[14]  x[15]  x[16]  x[17]  x[18]  x[19]  x[20]  x[21]   x[22]   x[23] 
// R1    R2    R3    R4    R5    R6    R7    R8    R9    R10   R11    R12    S1     S2     S3     S4     S5     S6     S7     S8     S9     S10     S11     S12

double[] irrigation_demand={0.0, 0.0, 3.28,  5.36,  3.0, 3.22, 3.22, 1.24, 8.06,  7.65,  7.65,  4.71 };
//                          Jan, Feb, March, Aprl,  May, June, July, Agst, Sptmr, Octbr, Nvmbr, Dcmbr
double[] deficit=new double[12];

for(int i=0;i<12;i++)
{deficit[i]=irrigation_demand[i]-x[i];}
 
double sum=0.0;
for(int i=0;i<12;i++)
{sum+= deficit[i]*deficit[i];}
return sum+(300000000007.38*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+H6(x)+H7(x)+H8(x)+H9(x)+H10(x)+H11(x)+H12(x)))    ;
}	

double H1(double x[])
{
	
double St1=0.0;
double St2=0.0;
 
St1=x[12];
St2=x[13];

double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78}; 

double 	A0=0.002*St1*St1+0.3446*St1+2.6533;//m^2	
double Evap0=A0*evap_rate[0];
double hh1=St2-(St1+I_med[0]-x[0]-Evap0);
return Math.abs(hh1);
}

double H2(double x[])
{
 
 
double St2=x[13];
double St3=x[14];
 
	
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
 

double 	A1=0.002*St2*St2+0.3446*St2+2.6533;//m^2		
double Evap1=A1*evap_rate[1];
double hh2=St3-(St2+I_med[1]-x[1]-Evap1);
return Math.abs(hh2);
}
	
double H3(double x[])
{
double St3=x[14];
double St4=x[15];	
	
 
	
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78}; 

double 	A2=0.002*St3*St3+0.3446*St3+2.6533;//m^2		
double Evap2=A2*evap_rate[2];
double hh3=St4-(St3+I_med[2]-x[2]-Evap2 );
return Math.abs(hh3);
}	

double H4(double x[])
{

double St4=x[15];
double St5=x[16];		

 	
	
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
 
double 	A3=0.002*St4*St4+0.3446*St4+2.6533;//m^2	
double Evap3=A3*evap_rate[3];
double hh4=St5-(St4+I_med[3]-x[3]-Evap3);
return Math.abs(hh4);
}	

double H5(double x[])
{
	
double St5=x[16];
double St6=x[17];	
	
 
	
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
 
 
double 	A4=0.002*St5*St5+0.3446*St5+2.6533;//m^2	
double Evap4=A4*evap_rate[4];
double hh5=St6-(St5+I_med[4]-x[4]-Evap4 );
return Math.abs(hh5);
}


double H6(double x[])
{

double St6=x[17];
double St7=x[18];		
 	
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
  
double 	A5=0.002*St6*St6+0.3446*St6+2.6533;//m^2	
double Evap5=A5*evap_rate[5];
double hh6=St7-(St6+I_med[5]-x[5]-Evap5 );
return Math.abs(hh6);
}


double H7(double x[])
{
	
double St7=x[18];
double St8=x[19];		
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
 
double 	A6=0.002*St7*St7+0.3446*St7+2.6533;//m^2	
double Evap6=A6*evap_rate[6];
double hh7=St8-(St7+I_med[6]-x[6]-Evap6 );
return Math.abs(hh7);
}



double H8(double x[])
{
double St8=x[19];
double St9=x[20];		
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
 
double 	A7=0.002*St8*St8+0.3446*St8+2.6533;//m^2	
double Evap7=A7*evap_rate[7];
double hh8=St9-(St8+I_med[7]-x[7]-Evap7 );
return Math.abs(hh8);
}


double H9(double x[])
{
	
double St9=x[20];
double St10=x[21];			
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
double 	A8=0.002*St9*St9+0.3446*St9+2.6533;//m^2	
double Evap8=A8*evap_rate[8];
double hh9=St10-(St9+I_med[8]-x[8]-Evap8 );
return Math.abs(hh9);
}


double H10(double x[])
{
	
double St10=x[21];
double St11=x[22];		
	
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
 
double 	A9=0.002*St10*St10+0.3446*St10+2.6533;//m^2	
double Evap9=A9*evap_rate[9];
double hh10=St11-(St10+I_med[9]-x[9]-Evap9);
return Math.abs(hh10);
}


double H11(double x[])
{

double St11=x[22];
double St12=x[23];	
		
	
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
 
 
double 	A10=0.002*St11*St11+0.3446*St11+2.6533;//m^2		
double Evap10=A10*evap_rate[10] ;
double hh11=St12-(St11+I_med[10]-x[10]-Evap10);
return Math.abs(hh11);
}

	
double H12(double x[])
{
	
double St12=x[23];
double St1=x[12];
 
double evap_rate[]={0.115, 0.1223, 0.1336, 0.1161, 0.1083, 0.0938, 0.0963, 0.0972, 0.0928, 0.0862, 0.0814, 0.0846 }; // m/month
double[]   I_med={ 4.17, 2.03, 3.79, 3.43, 3.37, 3.26,  5.71, 6.31,5.6, 14.87, 18.17, 12.78};
 
double 	A11=0.002*St12*St12+0.3446*St12+2.6533;//m^2		
double Evap11=A11*evap_rate[11];
double hh12=St1-(St12+I_med[11]-x[11]-Evap11);
return Math.abs(hh12);
}


 



 


}






class cec_g01 extends f_xj
{
 double func(double x[])
{
double top1=0.0;
double top2=0.0;
double top3=0.0;
for(int i=0;i<4;i++)
{top1+=x[i];}
for(int i=0;i<4;i++)
{top2+=x[i]*x[i];}
for(int i=4;i<13;i++)
{top3+=x[i];}
double fnc=5.0*top1-5.0*top2-top3;

double mu=40.0;
return fnc+mu*(G1(x)+G2(x)+G3(x)+G4(x)+G5(x)+G6(x)+G7(x)+G8(x)+G9(x));
}	

 

double G1(double x[])
{return Math.pow(Math.max(0.0,    2.0*x[0]+2.0*x[1]+x[9]+x[10]-10.0       ),2.0);  }

double G2(double x[])
{return Math.pow(Math.max(0.0,    2.0*x[0]+2.0*x[2]+x[9]+x[11]-10.0       ),2.0);  }

double G3(double x[])
{return Math.pow(Math.max(0.0,    2.0*x[1]+2.0*x[2]+x[10]+x[11]-10.0       ),2.0);  }

double G4(double x[])
{return Math.pow(Math.max(0.0,    -8.0*x[0]+x[9]      ),2.0);  }

double G5(double x[])
{return Math.pow(Math.max(0.0,    -8.0*x[1]+x[10]      ),2.0);  }

double G6(double x[])
{return Math.pow(Math.max(0.0,    -8.0*x[2]+x[11]      ),2.0);  }

double G7(double x[])
{return Math.pow(Math.max(0.0,    -2.0*x[3]-x[4]+x[9]     ),2.0);  }

double G8(double x[])
{return Math.pow(Math.max(0.0,      -2.0*x[5]-x[6]+x[10]     ),2.0);  }

double G9(double x[])
{return Math.pow(Math.max(0.0,      -2.0*x[7]-x[8]+x[11]     ),2.0);  }
 
}



class cec_g02 extends f_xj
{
 double func(double x[])
{
int DD=x.length;	
double top1=0.0;
double top2=1.0;
double top3=0.0;
for(int i=0;i<DD;i++)
{top1+= Math.pow(Math.cos(x[i]),4.0);}

for(int i=0;i<DD;i++)
{top2*=Math.pow(Math.cos(x[i]),2.0);}

for(int i=0;i<DD;i++)
{top3+=(double)(i+1)*x[i]*x[i];}

double fncc=-Math.abs((top1-2.0*top2)/Math.sqrt(top3));

 

double mu=80000.0;
return fncc+mu*(G1(x)+G2(x));
}	

 

double G1(double x[])
{
	double sum=1.0;
	for(int i=0;i<x.length;i++)
	{sum*=x[i];}
	
	return Math.pow(Math.max(0.0,    0.75-sum       ),2.0);  
}

double G2(double x[])
{
	int DD1=x.length;
	double sum1=0.0;
	for(int i=0;i<x.length;i++)
	{sum1+=x[i];}
	return Math.pow(Math.max(0.0,   sum1-(double)DD1 *7.5      ),2.0);  
}

  
}




class cec_g03 extends f_xj
{
 double func(double x[])
{
int DD=x.length;	
 
double top1=1.0;
 
for(int i=0;i<DD;i++)
{top1*= x[i];}

double fncc=-Math.pow(Math.sqrt((double)DD),(double)DD)*top1; 
  

double mu=17000000.0;  //sh
//double mu=1500.0;
return fncc+mu*(G1(x));
}	

 

double G1(double x[])
{
	double sum=0.0;
	for(int i=0;i<x.length;i++)
	{sum+=x[i]*x[i];}
	
	return Math.abs(sum-1.0);  
}

}



class cec_g04 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=357000000000000.95989;
return (5.3578547*x[2]*x[2])+(0.8356891*x[0]*x[4])+(37.293239*x[0])-(40792.141)+(mu*(G1(x)+G2(x)+G3(x)+G4(x)+G5(x)+G6(x)));
}

double G1(double x[])
{

return Math.pow(Math.max(0.0,85.334407+0.0056858*x[1]*x[4]+0.0006262*x[0]*x[3]-0.0022053*x[2]*x[4]-92.0),2.0);	

}
double G2(double x[])
{
return Math.pow(Math.max(0.0,-85.334407-0.0056858*x[1]*x[4]-0.0006262*x[0]*x[3]+0.0022053*x[2]*x[4]),2.0);	
}
double G3(double x[])
{
return Math.pow(Math.max(0.0,80.51249+0.0071317*x[1]*x[4]+0.0029955*x[0]*x[1]+0.0021813*x[2]*x[2]-110.0),2.0);	
}
double G4(double x[])
{
return Math.pow(Math.max(0.0,-80.51249-0.0071317*x[1]*x[4]-0.0029955*x[0]*x[1]-0.0021813*x[2]*x[2]+90.0),2.0);	
}
double G5(double x[])
{
return Math.pow(Math.max(0.0,9.300961+0.0047026*x[2]*x[4]+0.0012547*x[0]*x[2]+0.0019085*x[2]*x[3]-25.0),2.0);	
}
double G6(double x[])
{
return Math.pow(Math.max(0.0,-9.300961-0.0047026*x[2]*x[4]-0.0012547*x[0]*x[2]-0.0019085*x[2]*x[3]+20.0),2.0);	
}
}



 


class cec_g05 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1000.2;
double s1=((3.0*x[0])+(1e-6*x[0]*x[0]*x[0])+(2.0*x[1])+((2e-6/3.0)*x[1]*x[1]*x[1]))+mu*(G1(x)+G2(x)+H1(x)+H2(x)+H3(x));
return s1;
}

double G1(double x[])
{
return  Math.pow(Math.max(0.0,x[2]-x[3]-0.55),2.0);	
}

double G2(double x[])
{
return Math.pow(Math.max(0.0,x[3]-x[2]-0.55),2.0);		
}

double H1(double x[])
{
return Math.abs(1000.0*(Math.sin(-x[2]-0.25)+Math.sin(-x[3]-0.25))+894.8-x[0])-1e-8;	
}

double H2(double x[])
{
return Math.abs(1000.0*(Math.sin(x[2]-0.25)+Math.sin(x[2]-x[3]-0.25))+894.8-x[1])-1e-8;	
}

double H3(double x[])
{
return Math.abs(1000.0*(Math.sin(x[3]-0.25)+Math.sin(x[3]-x[2]-0.25))+1294.8)-1e-8;	
}
}



class cec_g06 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1000000000000.2;
double s1= (x[0]-10.0)*(x[0]-10.0)*(x[0]-10.0)+(x[1]-20.0)*(x[1]-20.0)*(x[1]-20.0)+mu*(G1(x)+G2(x));
return s1;
}

double G1(double x[])
{
return  Math.pow(Math.max(0.0,-(x[0]-5.0)*(x[0]-5.0)-(x[1]-5.0)*(x[1]-5.0)+100.0),2.0);	
}

double G2(double x[])
{
return Math.pow(Math.max(0.0,(x[0]-6.0)*(x[0]-6.0)+(x[1]-5.0)*(x[1]-5.0)-82.81),2.0);		
}

 }

class cec_g07 extends f_xj
{
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=10000.00007;
double fnc=(x[0]*x[0])+(x[1]*x[1])+(x[0]*x[1])-(14.0*x[0])-(16.0*x[1])+((x[2]-10.0)*(x[2]-10.0))+(4.0*(x[3]-5.0)*(x[3]-5.0))+((x[4]-3.0)*(x[4]-3.0))+(2.0*(x[5]-1.0)*(x[5]-1.0))+(5.0*x[6]*x[6])+(7.0*(x[7]-11.0)*(x[7]-11.0))+(2.0*(x[8]-10.0)*(x[8]-10.0))+((x[9]-7.0)*(x[9]-7.0))+45.0;
return fnc+mu*(G1(x)+G2(x)+G3(x)+G4(x)+G5(x)+G6(x)+G7(x)+G8(x));
}		
	
double G1(double x[])
{return Math.pow(Math.max(0.0,     -105.0+4.0*x[0]+5.0*x[1]-3.0*x[6]+9.0*x[7]       ),2.0);  }

double G2(double x[])
{return Math.pow(Math.max(0.0,     10.0*x[0]-8*x[1]-17*x[6]+2.0*x[7]       ),2.0);  }	
	
double G3(double x[])
{return Math.pow(Math.max(0.0,     -8.0*x[0]+2.0*x[1]+5*x[8]-2.0*x[9]-12.0       ),2.0);  }	
	
double G4(double x[])
{return Math.pow(Math.max(0.0,     (3.0*(x[0]-2.0)*(x[0]-2.0))+(4.0*(x[1]-3.0)*(x[1]-3.0))+2.0*x[2]*x[2]-7.0*x[3]-120.0       ),2.0);  }	
	
double G5(double x[])
{return Math.pow(Math.max(0.0,     5.0*x[0]*x[0]+8.0*x[1]+((x[2]-6.0)*(x[2]-6.0))-2.0*x[3]-40.0     ),2.0);  }		
	
double G6(double x[])
{return Math.pow(Math.max(0.0,     (x[0]*x[0])+(2.0*(x[1]-2.0)*(x[1]-2.0))-(2.0*x[0]*x[1])+14.0*x[4]-6.0*x[5]    ),2.0);  }	

double G7(double x[])
{return Math.pow(Math.max(0.0,     (0.5*(x[0]-8.0)*(x[0]-8.0))+(2.0*(x[1]-4.0)*(x[1]-4.0))+3.0*x[4]*x[4]-x[5]-30.0       ),2.0);  }	

double G8(double x[])
{return Math.pow(Math.max(0.0, -3.0*x[0]+6.0*x[1]+(12.0*(x[8]-8.0)*(x[8]-8.0))-7.0*x[9]            ),2.0);  }	
}


 

class cec_g08 extends f_xj
{
	
public double func(double x[]) 
{
//��z�m� istenen fonksiy	
double mu=100.00007;
double s1=-Math.sin(2.0*Math.PI*x[0])*Math.sin(2.0*Math.PI*x[0])*Math.sin(2.0*Math.PI*x[0])*Math.sin(2.0*Math.PI*x[1])/(x[0]*x[0]*x[0]*(x[0]+x[1]));
 
return s1+mu*(H1(x)+H2(x));
}	
	
double H1(double x[])
{return Math.pow(Math.max(0.0,     x[0]*x[0]-x[1]+1.0       ),2.0);                                       }	
	
double H2(double x[])
{return Math.pow(Math.max(0.0,    1.0-x[0]+((x[1]-4.0)*(x[1]-4.0))         ),2.0); }	
}



class cec_g09 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1000000000.25;
return ((x[0]-10.0)*(x[0]-10.0))+(5.0*(x[1]-12.0)*(x[1]-12.0))+(x[2]*x[2]*x[2]*x[2])+(3.0*(x[3]-11.0)*(x[3]-11.0))+(10.0*(x[4]*x[4]*x[4]*x[4]*x[4]*x[4]))+(7.0*x[5]*x[5])+(x[6]*x[6]*x[6]*x[6])-(4.0*x[5]*x[6])-10*x[5]-8.0*x[6]+mu*(G1(x)+G2(x)+G3(x)+G4(x));
}

double G1(double x[])
{
return Math.pow(Math.min(0.0,127.0-2.0*x[0]*x[0]-3.0*x[1]*x[1]*x[1]*x[1]-x[2]-4.0*x[3]*x[3]-5.0*x[4]),2.0);	
}
double G2(double x[])
{
return Math.pow(Math.min(0.0,282.0-7.0*x[0]-3.0*x[1]-10.0*x[2]*x[2]-x[3]+x[4]),2.0);	
}
double G3(double x[])
{
return Math.pow(Math.min(0.0,196.0-23.0*x[0]-x[1]*x[1]-6.0*x[5]*x[5]+8.0*x[6]),2.0);	
}
double G4(double x[])
{
return Math.pow(Math.min(0.0,-4.0*x[0]*x[0]-x[1]*x[1]+3.0*x[0]*x[1]-2.0*x[2]*x[2]-5.0*x[5]+11.0*x[6]),2.0);	
}
}


class cec_g10 extends f_xj
{
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=10000000000.00007;

return x[0]+x[1]+x[2]+mu*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+H6(x));
}	
	
double H1(double x[])
{return Math.pow(Math.max(0.0,      -1.0+0.0025*(x[3]+x[5])       ),2.0);                                       }	
	
double H2(double x[])
{return Math.pow(Math.max(0.0,    -1.0+0.0025*(x[4]+x[6]-x[3])         ),2.0); }	
	
double H3(double x[])
{return Math.pow(Math.max(0.0,      -1.0+0.01*(x[7]-x[4])      ),2.0); }	
	
double H4(double x[])
{return Math.pow(Math.max(0.0,      -x[0]*x[5]+833.33252*x[3]+100.0*x[0]-83333.333       ),2.0);   }	

double H5(double x[])
{return Math.pow(Math.max(0.0,      -x[1]*x[6]+1250.0*x[4]+x[1]*x[3]-1250.0*x[3]       ),2.0);   }

double H6(double x[])
{return Math.pow(Math.max(0.0,      -x[2]*x[7]+1250000.0+x[2]*x[4]-2500.0*x[4]       ),2.0);   }
}
 

class cec_g11 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=5.0;
double s1=x[0]*x[0]+(x[1]-1.0)*(x[1]-1.0)+mu*(H1(x));
return s1;
}

double H1(double x[])
{
return Math.abs(x[1]-x[0]*x[0])-1e-8;
}
}



class cec_g13 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=0.07;
double s1=Math.exp(x[0]*x[1]*x[2]*x[3]*x[4])+mu*(H1(x)+H2(x)+H3(x));
return s1;
}

double H1(double x[])
{
  int n=x.length;
  double d=0.0;
  for(int i=0;i<n;i++)
  {d+=x[i]*x[i];}
  return Math.abs(d-10.0)-1e-8; 	
	
}

double H2(double x[])
{
return  Math.abs(x[1]*x[2]-5.0*x[3]*x[4])-1e-8; 	
}

double H3(double x[])
{
return Math.abs(x[0]*x[0]*x[0]+x[1]*x[1]*x[1]+1.0)-1e-8;	
}

}



class cec_g14 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double[] c={-6.089,-17.164, -34.054, -5.914,-24.721,-14.986,-24.1,-10.708,-26.662, -22.719};
double mu=90.07;
double sum=0.0;

for(int i=0;i<10;i++)
{sum+=x[i]*(c[i]+Math.log(x[i]/(x[0]+x[1]+x[2]+x[3]+x[4]+x[5]+x[6]+x[7]+x[8]+x[9])));}


double s1=sum+mu*(H1(x)+H2(x)+H3(x));
return s1;
}

double H1(double x[])
{
 
  return Math.abs( x[0]+2.0*x[1]+2.0*x[2]+x[5]+x[9]-2.0 ); 	
	
}

double H2(double x[])
{
return  Math.abs( x[3]+2.0*x[4]+x[5]+x[6]-1.0 ); 	
}

double H3(double x[])
{
return Math.abs( x[2]+x[6]+x[7]+2.0*x[8]+x[9]-1.0  )-1e-8;	
}

}



class cec_g15 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
 double mu=90.07;
 double fx=1000-x[0]*x[0]-2.0*x[1]*x[1]-x[2]*x[2]-x[0]*x[1]-x[0]*x[2];

double s1=fx+mu*(H1(x)+H2(x) );
return s1;
}

double H1(double x[])
{
 
  return Math.abs( x[0]*x[0]+x[1]*x[1]+x[2]*x[2]-25.0   ); 	
	
}

double H2(double x[])
{
return  Math.abs( 8.0*x[0]+14.0*x[1]+7.0*x[2]-56.0 ); 	
}

 

}



class cec_g17 extends f_xj          
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
 double mu=200.07;
double f1=0.0;
double f2=0.0;

 if((x[0]>=0.0)&&(x[0]<300.0))
 {f1=30.0*x[0];}
 else if ((x[0]>=300.0)&&(x[0]<400.0))
 {f1=31.0*x[0];}
 
 if((x[1]>=0.0)&&(x[1]<100.0))
 {f2=28.0*x[1];}
 else if ((x[1]>=100.0)&&(x[1]<200.0))
 {f2=29.0*x[1];} 
 else if ((x[1]>=200.0)&&(x[1]<1000.0))
 {f2=30.0*x[1];}
 
 
double s1=f1+f2+mu*(H1(x)+H2(x)+H3(x)+H4(x));
return s1;
}

double H1(double x[])
{
  double s1=-x[0]+300.0- (x[2]*x[3]*Math.cos(1.48477-x[5])/131.078)+ (0.90798*x[2]*x[2]*Math.cos(1.47588)/131.078);
  
  
  return Math.abs( s1   ); 	
	
}

double H2(double x[])
{
  double s2=-x[1]- (x[2]*x[3]*Math.cos(1.48477+x[5])/131.078)+ (0.90798*x[3]*x[3]*Math.cos(1.47588)/131.078);
	
	
return  Math.abs( s2 ); 	
}

 
double H3(double x[])
{
  double s3=-x[4]- (x[2]*x[3]*Math.sin(1.48477+x[5])/131.078)+ (0.90798*x[3]*x[3]*Math.sin(1.47588)/131.078);
	
	
return  Math.abs( s3 ); 	
}

double H4(double x[])
{
  double s4=200.0- (x[2]*x[3]*Math.sin(1.48477-x[5])/131.078)+ (0.90798*x[2]*x[2]*Math.sin(1.47588)/131.078);
	
	
return  Math.abs( s4 ); 	
}


}



 


class cec_g18 extends f_xj
{
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=1000000000000.00007;

return   -0.5*(x[0]*x[3]-x[1]*x[2]+x[2]*x[8]-x[4]*x[8]+x[4]*x[7]-x[5]*x[6])+mu*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+H6(x)+H7(x)+H8(x)+H9(x)+H10(x)+H11(x)+H12(x)+H13(x));
}	
	
double H1(double x[])
{return Math.pow(Math.max(0.0,     x[2]*x[2]+x[3]*x[3]-1.0       ),2.0);                                       }	
	
double H2(double x[])
{return Math.pow(Math.max(0.0,    x[8]*x[8]-1.0         ),2.0); }	
	
double H3(double x[])
{return Math.pow(Math.max(0.0,      x[4]*x[4]+x[5]*x[5]-1.0      ),2.0); }	
	
double H4(double x[])
{return Math.pow(Math.max(0.0,      x[0]*x[0]+(x[1]-x[8])*(x[1]-x[8])-1.0      ),2.0);   }	

double H5(double x[])
{return Math.pow(Math.max(0.0,      ((x[0]-x[4])*(x[0]-x[4]))+((x[1]-x[5])*(x[1]-x[5]))-1.0      ),2.0);   }

double H6(double x[])
{return Math.pow(Math.max(0.0,      ((x[0]-x[6])*(x[0]-x[6]))+((x[1]-x[7])*(x[1]-x[7]))-1.0       ),2.0);   }

double H7(double x[])
{return Math.pow(Math.max(0.0,      ((x[2]-x[4])*(x[2]-x[4]))+((x[3]-x[5])*(x[3]-x[5]))-1.0       ),2.0);   }

double H8(double x[])
{return Math.pow(Math.max(0.0,      ((x[2]-x[6])*(x[2]-x[6]))+((x[3]-x[7])*(x[3]-x[7]))-1.0       ),2.0);   }

double H9(double x[])
{return Math.pow(Math.max(0.0,      ((x[6])*(x[6]))+((x[7]-x[8])*(x[7]-x[8]))-1.0        ),2.0);   }

double H10(double x[])
{return Math.pow(Math.max(0.0,        x[1]*x[2]-x[0]*x[3]   ),2.0);   }

double H11(double x[])
{return Math.pow(Math.max(0.0,      -x[2]*x[8]       ),2.0);   }

double H12(double x[])
{return Math.pow(Math.max(0.0,      x[4]*x[8]       ),2.0);   }

double H13(double x[])
{return Math.pow(Math.max(0.0,      x[5]*x[6]-x[4]*x[7]      ),2.0);   }

}


class cec_g21 extends f_xj
{
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=100000000000000000000000.00007;

return  x[0]+mu*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+G1(x));
}	
	
double G1(double x[])
{return Math.pow(Math.max(0.0,     -x[0]+35.0*Math.pow(x[1],0.6)+35.0*Math.pow(x[2],0.6)       ),2.0);                                       }	
	
double H1(double x[])
{return Math.abs( -300.0*x[2]+7500*x[4]-7500*x[5]-25.0*x[3]*x[4]+25.0*x[3]*x[5] + x[2]*x[3]               ); }	
	
double H2(double x[])
{return Math.abs(100.0*x[1]+155.365*x[3]+2500.0*x[6]-x[1]*x[3]-25.0*x[3]*x[6]-15536.5); }	
	
double H3(double x[])
{return Math.abs(-x[4]+Math.log(-x[3]+900.0));   }	

double H4(double x[])
{return Math.abs(-x[5]+Math.log(x[3]+300.0));   }

double H5(double x[])
{return   Math.abs(-x[6]+Math.log(-2.0*x[3]+700.0));   }

 
}


class cec_g22 extends f_xj
{
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=100000000000000000000000.00007;

return  x[0]+mu*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+H6(x));
}	
	
double G1(double x[])
{return Math.pow(Math.max(0.0,     -x[0]+Math.pow(x[1],0.6)+Math.pow(x[2],0.6)+Math.pow(x[3],0.6)       ),2.0);                                       }	
	
double H1(double x[])
{return Math.abs(  x[4]- 100000*x[7]+10000000            ); }	
	
double H2(double x[])
{return Math.abs( x[5]+100000*x[7]-  100000*x[8]     ); }	
	
double H3(double x[])
{return Math.abs( x[6]+ 100000*x[8] -50000000.0  );   }	

double H4(double x[])
{return Math.abs( x[4]+100000*x[9]-3.3e7   );   }

double H5(double x[])
{return   Math.abs( x[5]+100000*x[10]-4.4e7    );   }

double H6(double x[])
{return   Math.abs( x[6]+100000*x[11]-6.6e7    );   }

double H7(double x[])
{return   Math.abs( x[4]-120.0*x[1]*x[12]    );   } 

double H8(double x[])
{return   Math.abs( x[5]-80.0*x[2]*x[13]    );   } 

double H9(double x[])
{return   Math.abs( x[6]-40.0*x[3]*x[14]    );   } 

double H10(double x[])
{return   Math.abs( x[7]-x[10]+x[15]    );   }

double H11(double x[])
{return   Math.abs( x[8]-x[11]+x[16]    );   }

double H12(double x[])
{return   Math.abs(  -x[17]+Math.log( x[9]-100)       );   }

double H13(double x[])
{return   Math.abs(  -x[18]+Math.log( -x[7]+300)       );   }

double H14(double x[])
{return   Math.abs(  -x[19]+Math.log(x[15])       );   }

double H15(double x[])
{return   Math.abs(  -x[20]+Math.log(-x[8]+400)       );   }

double H16(double x[])
{return   Math.abs(  -x[21]+Math.log(x[16])       );   }

double H17(double x[])
{return   Math.abs(  -x[7]-x[9]+x[12]*x[17]-x[12]*x[18]+400.0       );   }

double H18(double x[])
{return   Math.abs(  x[7]-x[8]-x[10]+x[13]*x[19]-x[13]*x[20]+400.0       );   }

double H19(double x[])
{return   Math.abs(  x[8]-x[11]-4.60517*x[14]+x[14]*x[21]+100.0       );   }

}



class cec_g23 extends f_xj
{
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=100.00007;

return  -9.0*x[4]-15.0*x[7]+6.0*x[0]+16.0*x[1]+10.0*(x[5]+x[6])+mu*(G1(x)+G2(x)+H1(x)+H2(x)+H3(x)+H4(x));
}	
	
double G1(double x[])
{return Math.pow(Math.max(0.0,       x[8]*x[2]+0.02*x[5]-0.025*x[4]      ),2.0);                                       }	
	
double G2(double x[])
{return Math.pow(Math.max(0.0,       x[8]*x[3]+0.02*x[6]-0.015*x[7]      ),2.0); }	
	
double H1(double x[])
{return Math.abs( x[0]+x[1]-x[2]-x[3]     ); }	
	
double H2(double x[])
{return Math.abs(  0.03*x[0]+0.01*x[1]-x[8]*(x[2]+x[3])  );   }	

double H3(double x[])
{return Math.abs( x[2]+x[5]-x[4]   );   }

double H4(double x[])
{return   Math.abs( x[3]+x[6]-x[7]   );   }

}



class cec_g24 extends f_xj
{
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=100000000000.00007;

return  -x[0]-x[1]+mu*(G1(x)+G2(x) );
}	
	
double G1(double x[])
{return Math.pow(Math.max(0.0,       -2.0*x[0]*x[0]*x[0]*x[0]+8.0*x[0]*x[0]*x[0]-8.0*x[0]*x[0]+x[1]-2.0     ),2.0);                                       }	
	
double G2(double x[])
{return Math.pow(Math.max(0.0,        -4.0*x[0]*x[0]*x[0]*x[0]+32.0*x[0]*x[0]*x[0]-88.0*x[0]*x[0]+96.0*x[0]+x[1]-36.0      ),2.0); }	
}


class threebartruss extends f_xj         
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=10000000.100000000;
double s1=((2.0*Math.sqrt(2.0)*x[0]+x[1])*100)+mu*(H1(x)+H2(x)+H3(x));
return s1;
}

double H1(double x[])
{return Math.pow(Math.max(0.0, (((Math.sqrt(2.0)*x[0]+x[1])/(Math.sqrt(2)*x[0]*x[0]+2.0*x[0]*x[1]))*2.0)-2.0  ),2.0);}

double H2(double x[])
{return  Math.pow(Math.max(0.0,    2.0*(x[1]/(Math.sqrt(2)*x[0]*x[0]+2.0*x[0]*x[1]))-2.0   ),2.0);}

double H3(double x[])
{return  Math.pow(Math.max(0.0,   2.0*(1.0/(Math.sqrt(2.0)*x[1]+x[0]))-2.0   ),2.0);}
}


//Tension/compression spring design problem
class tensioncompression extends f_xj         
{
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=10000000.3;
double s1=((x[2]+2.0)*x[1]*x[0]*x[0])+(mu*(H1(x)+H2(x)+H3(x)+H4(x)));
return s1;
}

double H1(double x[])
{return Math.pow(Math.max(0.0,         1.0-((x[1]*x[1]*x[1]*x[2])/(71785.0*x[0]*x[0]*x[0]*x[0]))                  ),2.0);}

double H2(double x[])
{return  Math.pow(Math.max(0.0,        (((4.0*x[1]*x[1])-(x[0]*x[1]))/(12566.0*(x[1]*x[0]*x[0]*x[0]-x[0]*x[0]*x[0]*x[0])))+(1.0/(5108.0*x[0]*x[0]))-1.0              ),2.0);}

double H3(double x[])
{return  Math.pow(Math.max(0.0,        1.0-((140.45*x[0])/(x[1]*x[1]*x[2]))        ),2.0);}

double H4(double x[])
{return  Math.pow(Math.max(0.0,     ((x[0]+x[1])/1.5)-1.0        ),2.0);}
}


// speed reducer design problem
class speedreducer extends f_xj         
{
public double func(double x[]) 
{
	
  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}	
	//��z�m� istenen fonksiyon	
double mu=80000.7;
double s1=0.7854*x[0]*x[1]*x[1]*(3.3333*x[2]*x[2]+14.9334*x[2]-43.0934)-(1.508*x[0]*(x[5]*x[5]+x[6]*x[6]))+(7.4777*(x[5]*x[5]*x[5]+x[6]*x[6]*x[6]))+(0.7854*(x[3]*x[5]*x[5]+x[4]*x[6]*x[6]))+(mu*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+H6(x)+H7(x)+H8(x)+H9(x)+H10(x)+H11(x)));
return s1;
}

double H1(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	return Math.pow(Math.max(0.0,         (27.0/(x[0]*x[1]*x[1]*x[2]))-1.0                 ),2.0);
	
	}

double H2(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	return  Math.pow(Math.max(0.0,       (397.5/(x[0]*x[1]*x[1]*x[2]*x[2]))-1.0             ),2.0);

}

double H3(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	return  Math.pow(Math.max(0.0,      ((1.93*x[3]*x[3]*x[3])/(x[1]*x[2]*x[5]*x[5]*x[5]*x[5]))-1.0          ),2.0);

}

double H4(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	
	return  Math.pow(Math.max(0.0,     ((1.93*x[4]*x[4]*x[4])/(x[1]*x[6]*x[6]*x[6]*x[6]*x[2]))-1.0        ),2.0);


}

double H5(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	return  Math.pow(Math.max(0.0,     (Math.sqrt((745.0*(x[3]/(x[1]*x[2])))*(745.0*(x[3]/(x[1]*x[2])))+16.9e6)/(110.0*x[5]*x[5]*x[5]))-1.0                                    ),2.0);}

double H6(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	
	return  Math.pow(Math.max(0.0,    (Math.sqrt((745.0*(x[4]/(x[1]*x[2])))*(745.0*(x[4]/(x[1]*x[2])))+157.5e6)/(85.0*x[6]*x[6]*x[6]))-1.0     ),2.0);}

double H7(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	
	return  Math.pow(Math.max(0.0,     x[1]*x[2]-40.0       ),2.0);}

double H8(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	
	return  Math.pow(Math.max(0.0,     -x[0]+5.0*x[1]       ),2.0);}

double H9(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	
	return  Math.pow(Math.max(0.0,     x[0]-12.0*x[1]       ),2.0);}


double H10(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	return  Math.pow(Math.max(0.0,     1.5*x[5]+1.9-x[3]       ),2.0);}

double H11(double x[])
{
	  			if (x[2]<=0.0833)
  			{x[2]=17.0;}
  			if ((x[2]>0.0833)&&(x[2]<=(0.0833*2)))
  			{x[2]=18.0;}
  			if ((x[2]>(2*0.0833))&&(x[2]<=(0.0833*3)))
  			{x[2]=19.0;}
  			if ((x[2]>(3*0.0833))&&(x[2]<=(0.0833*4)))
  			{x[2]=20.0;}
  			if ((x[2]>(4*0.0833))&&(x[2]<=(0.0833*5)))
  			{x[2]=21.0;}
  			if ((x[2]>(5*0.0833))&&(x[2]<=(0.0833*6)))
  			{x[2]=22.0;}
  			if ((x[2]>(6*0.0833))&&(x[2]<=(0.0833*7)))
  			{x[2]=23.0;}
  			if ((x[2]>(7*0.0833))&&(x[2]<=(0.0833*8)))
  			{x[2]=24.0;}
  			if ((x[2]>(8*0.0833))&&(x[2]<=(0.0833*9)))
  			{x[2]=25.0;}
  			if ((x[2]>(9*0.0833))&&(x[2]<=(0.0833*10)))
  			{x[2]=26.0;}
  			if ((x[2]>(10*0.0833))&&(x[2]<=(0.0833*11)))
  			{x[2]=27.0;}
  			if ((x[2]>(11*0.0833))&&(x[2]<=(0.0833*12)))
  			{x[2]=28.0;}
	
	return  Math.pow(Math.max(0.0,     1.1*x[6]+1.9-x[4]       ),2.0);}
 
}


class weldedbeam extends f_xj         
{
	
double P=6000.0;
double L=14.0;
double E=30000000.0;	
double G=12000000.0;
double tomax=13600.0;
double sigmax=30000.0;
double deltamax=0.25;

double sigma(double x[])
{return (6.0*P*L)/(x[3]*x[2]*x[2]);}

double delta(double x[])
{return (4.0*P*L*L*L)/(E*x[2]*x[2]*x[2]*x[3]);}

double Pc(double x[])
{return (4.013*Math.sqrt(E*G*x[2]*x[2]*x[3]*x[3]*x[3]*x[3]*x[3]*x[3]/36.0)/L/L)*(1.0-((x[2]/(2.0*L))*Math.sqrt(E/(4.0*G))))        ;}
	
double J(double x[])
{return   2.0/Math.sqrt(2)*x[0]*x[1]*(x[1]*x[1]/12.0+0.25*(x[0]+x[2])*(x[0]+x[2]));                    }
	
double R(double x[])
{return	Math.sqrt(0.25*(x[1]*x[1]+(x[0]+x[2])*(x[0]+x[2])));}

double M(double x[])
{return P*(L+x[1]/2.0);}

double to1(double x[])
{return P/(Math.sqrt(2)*x[0]*x[1]);}

double to2(double x[])
{return M(x)*R(x)/J(x);}

double toend(double x[])
{return Math.sqrt(to1(x)*to1(x)+(2.0*to1(x)*to2(x)*x[1]/(2.0*R(x)))+to2(x)*to2(x));}
	
	
	
public double func(double x[]) 
{
//��z�m� istenen fonksiyon	
double mu=950000000000.000000015;
double s1=(1.10471*x[0]*x[0]*x[1])+(0.04811*x[2]*x[3]*(14.0+x[1]))+(mu*(H1(x)+H2(x)+H3(x)+H4(x)+H5(x)+H6(x)+H7(x)+H8(x)));
return s1;
}

double H1(double x[])
{return Math.pow(Math.max(0.0,         toend(x)-tomax                 ),2.0);}

double H2(double x[])
{return  Math.pow(Math.max(0.0,         sigma(x)-sigmax           ),2.0);}

double H3(double x[])
{return  Math.pow(Math.max(0.0,        x[0]-x[3]        ),2.0);}

double H4(double x[])
{return  Math.pow(Math.max(0.0,       -x[1]         ),2.0);}

double H5(double x[])
{return  Math.pow(Math.max(0.0,      0.125-x[0]         ),2.0);}

double H6(double x[])	
{return  Math.pow(Math.max(0.0,       delta(x)-deltamax         ),2.0);}

double H7(double x[])
{return  Math.pow(Math.max(0.0,       P-Pc(x)         ),2.0);}

double H8(double x[])
{return  Math.pow(Math.max(0.0,       -x[2]         ),2.0);}
}


 


public class  Slime_Mould_Algorithm_test
{
public static void main(String args[])
{	
  
                 
                 
                 
 
                      double[] Lower=new double[30];
                      double[] Upper=new double[30];
                       

                      
                      for(int i=0;i<30;i++)
                      {
	                   Lower[i]=-10.28;
                       Upper[i]=10.28;
                       
                      }

                      
int Maxiter=100;
int N=20;


 
    
      f34 ff=new f34();
 
      Slime_Mould_Algorithm wo=new Slime_Mould_Algorithm(ff,N,Lower,Upper,Maxiter);
     
 
    
    long startTime = System.currentTimeMillis();
 
      wo.toStringnew();
    long endTime   = System.currentTimeMillis();
           long totalTime = endTime - startTime;
           System.out.println((totalTime/1000.0)+" sec");
 
     Slime_Mould_Algorithm_test.main(args);




}	












}